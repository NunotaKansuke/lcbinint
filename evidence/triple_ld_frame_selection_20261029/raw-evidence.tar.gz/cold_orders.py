import json,sys,subprocess,os,concurrent.futures
from pathlib import Path
P=Path(__file__).resolve().parent;cases=json.loads((P/'cases.json').read_text());D=P/'cold-orders';D.mkdir(exist_ok=True)
def task(job):
 i,order=job;c=json.loads(json.dumps(cases[i]));n=len(c['epochs']);idx=list(range(n))if order=='normal'else list(range(n))[::-1]if order=='reverse'else list(range(n))+[0];c['epochs']=[c['epochs'][j]for j in idx];inp=D/f'{i}-{order}.input.json';inp.write_text(json.dumps(c));r=subprocess.run([sys.executable,str(P/'worker.py'),str(inp),'gradient'],capture_output=True,text=True,timeout=120,env=dict(os.environ,TRIPLE_BUILD=str(P/'candidate-package'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'));z=json.loads(r.stdout)if r.returncode==0 else dict(classification='worker_exit',code=r.returncode,stderr=r.stderr);z['indices']=idx;(D/f'{i}-{order}.json').write_text(json.dumps(z,indent=2));return i,order,z['classification']
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for r in pool.map(task,[(i,o)for i in [940,972,1508]for o in ['normal','reverse','duplicate']]):print(*r,flush=True)
