import sys,os,json,math,time,resource,subprocess,concurrent.futures
from pathlib import Path
P=Path(__file__).resolve().parent
if '--worker'in sys.argv:
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(30,32));os.sched_setaffinity(0,{1,2,3,4})
 import VBMicrolensing as V
 i=int(sys.argv[2]);name=sys.argv[3];c=json.loads((P/'cases.json').read_text())[i];p=c['params'];index={940:1,949:2,1041:2,1508:1}[i];t=c['epochs'][index];out=dict(case=i,index=index,parameter=name,samples=[],rtol=1e-9,method='Nopoly')
 D=P/'fd-references';D.mkdir(exist_ok=True);f=D/f'{i:04d}-{name}.json'
 if f.exists():out=json.loads(f.read_text())
 scales=dict(t0=p['tE']*p['rho']*.01,u0=p['rho']*.01,tE=p['tE']*p['rho']*.01/max(1,abs((t-p['t0'])/p['tE'])),alpha=p['rho']*.01/max(1,abs(p['u0'])),ang=1e-5,rho=p['rho']*.01)
 h=scales.get(name,abs(p[name])*1e-5)
 v=V.VBMicrolensing();v.SetMethod(v.Method.Nopoly);v.Tol=0.;v.RelTol=out['rtol'];v.a1=c['limb'];v.a2=0.;v.SetLDprofile(v.LDlinear)
 def value(par):
  vp=[math.log(par[k])if k in ['s','q','rho','tE','sep2','q2']else par[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']];return float(v.TripleLightCurve(vp,[t])[0][0])
 for step in [h,h*.5,h*.25]:
  if any(x['h']==step for x in out['samples']):continue
  a=time.thread_time();plus=value(dict(p,**{name:p[name]+step}));minus=value(dict(p,**{name:p[name]-step}));out['samples'].append(dict(h=step,plus=plus,minus=minus,derivative=(plus-minus)/(2*step),cpu_seconds=time.thread_time()-a));f.write_text(json.dumps(out,indent=2))
 sys.exit()
D=P/'fd-references';D.mkdir(exist_ok=True)
def task(job):
 i,name=job
 try:
  r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',str(i),name],capture_output=True,text=True,timeout=90,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'));z=dict(case=i,parameter=name,returncode=r.returncode,stderr=r.stderr[-2000:])
 except Exception as exc:z=dict(case=i,parameter=name,error=repr(exc))
 (D/f'{i:04d}-{name}-status.json').write_text(json.dumps(z));print(i,name,z.get('returncode',z.get('error')),flush=True)
jobs=[(i,k)for i in [949,1041,1508]for k in ['t0','u0','tE','alpha','rho','q','s','q2','sep2','ang']]
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:list(pool.map(task,jobs))
(P/'fd-complete.json').write_text(json.dumps(dict(jobs=len(jobs),finished=time.time())))
