import sys,json,math,resource,time
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent;R=P.parent.parent;resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(120,125))
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];sys.path.insert(0,str(P.parent/'triple_hardening_20261028/seeds-package'));import lcbinint as lc
import VBMicrolensing as V
i,j=int(sys.argv[1]),int(sys.argv[2]);c=json.loads((P/'cases.json').read_text())[i];p=c['params'];t=c['epochs'][j];D=P/'gradient-matrix';D.mkdir(exist_ok=True);out=dict(case=i,index=j,limb=c['limb'],rtol=c['rtol'],rows=[])
m=lc.LightCurve(lens='triple',ld_c=c['limb'],options=lc.Options(finite_source_tol=0.,finite_source_reltol=c['rtol']));z=m.info([t],p,with_gradient=True);out.update(native=z.gradients.tolist()[0],mu=z.magnifications.tolist(),status=z.status.tolist(),method=z.diagnostics['finite_source_method'].tolist())
def value(p,method):
 v=V.VBMicrolensing();v.SetMethod(getattr(v.Method,method));v.Tol=0.;v.RelTol=1e-8;v.a1=c['limb'];v.a2=0.;v.SetLDprofile(v.LDlinear);vp=[math.log(p[k])if k in ['s','q','rho','tE','sep2','q2']else p[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']];return float(v.TripleLightCurve(vp,[t])[0][0])
saved=D/f'{i:04d}.json'
if saved.exists():out=json.loads(saved.read_text())
for name in z.gradient_parameters:
 if any(row['parameter']==name for row in out['rows']):continue
 h=1e-3*{'t0':p['tE'],'u0':1.,'alpha':1.,'ang':1.}.get(name,abs(p[name]));row=dict(parameter=name,references={})
 for method in ['Multipoly','Nopoly']:
  samples=[]
  for step in [h,h*.5,h*.25]:
   plus=value(dict(p,**{name:p[name]+step}),method);minus=value(dict(p,**{name:p[name]-step}),method);samples.append(dict(h=step,plus=plus,minus=minus,derivative=(plus-minus)/(2*step)))
  row['references'][method]=samples
 out['rows'].append(row);(D/f'{i:04d}.json').write_text(json.dumps(out,indent=2))
print(i,len(out['rows']),flush=True)
