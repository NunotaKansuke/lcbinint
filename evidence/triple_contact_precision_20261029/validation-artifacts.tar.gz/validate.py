from pathlib import Path
import json
P=Path(__file__).resolve().parent;Q=P.parent/'triple_hardening_20261028';cases=json.loads((P/'cases.json').read_text());old=json.loads((Q/'validated-reference-comparisons.json').read_text());refs={(r['case'],r['index']):r for r in old};rows=[]
for e in ['value','gradient']:
 for i,c in enumerate(cases):
  a=json.loads((P/'rows'/f'{i:04d}-{e}.json').read_text())
  if 'mu'not in a:continue
  for j,mu in enumerate(a['mu']):
   if a['status'][j]!=0 or mu is None or (i,j)not in refs:continue
   r=dict(refs[i,j],native=mu,engine=e);r['relative_error']=max(abs(mu/b-1)for b in r['reference_values']);r['ratio']=r['relative_error']/c['rtol'];rows.append(r)
r=dict(comparisons=len(rows),conditions=len({r['case']for r in rows}),points=len({(r['case'],r['index'])for r in rows}),exceedances=[r for r in rows if r['ratio']>1],maximum_ratio=max(r['ratio']for r in rows));(P/'validated-reference-summary.json').write_text(json.dumps(r,indent=2));(P/'validated-reference-comparisons.json').write_text(json.dumps(rows,indent=2));print(r)
