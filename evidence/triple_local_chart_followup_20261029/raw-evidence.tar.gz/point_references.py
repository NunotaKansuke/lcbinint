import sys,json,math
from pathlib import Path
P=Path(__file__).resolve().parent;results={}
for case in [403,460]:
 sys.argv=[__file__,str(case)];ns={'__file__':str(P/'mp_reference.py'),'__name__':'point_validation'};exec(compile((P/'mp_reference.py').read_text().split('out=dict(case=case,')[0],str(P/'mp_reference.py'),'exec'),ns)
 mp=ns['mp'];p=ns['p'];c=ns['c'];a=p['alpha'];w=mp.mpc(-p['u0']*math.sin(a),p['u0']*math.cos(a));h=.7071067811865475244;axes=[(1,0),(0,1),(-1,0),(0,-1)];diagonals=[(h,h),(-h,h),(-h,-h),(h,-h)];directions=[(0,0)]+[(p['rho']*x,p['rho']*y)for x,y in axes]+[(p['rho']*.5*x,p['rho']*.5*y)for x,y in axes]+[(p['rho']*x,p['rho']*y)for x,y in diagonals];roots=ns['roots_at'](w);rows=[]
 for j,(x,y)in enumerate(directions):
  # Exactly reproduce the binary64 public sampling coordinates, then solve independently.
  source=mp.mpc(float(w.real)+x,float(w.imag)+y);images=[ns['solve'](z,source)for z in roots];assert all(v is not None for v in images)
  value=sum(1/abs(v[1])for v in images);rows.append(dict(index=j,source=[float(source.real),float(source.imag)],mu=str(value),maximum_residual=str(max(v[2]for v in images))))
 results[str(case)]=rows
(P/'point-references.json').write_text(json.dumps(results,indent=2))
print(json.dumps({k:[float(r['mu'])for r in v]for k,v in results.items()},indent=2))
