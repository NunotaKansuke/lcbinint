// Physical interval contraction fallback. Candidate roots are proposals only;
// six disjoint contraction disks certify all degree-six critical roots.
inline std::vector<Disk> interval_critical_cover(const Geometry&p,double phi,double half,
                                               std::vector<Complex>&roots) {
 using B=interval_detail::Interval<double>;using C=coefficient_detail::C<B>;
 if(!interval_detail::environment_ok() || roots.size()!=6 || !(half>=0) || half>pi)return {};
 auto reciprocal=[](B a){return B(interval_detail::down(1/a.hi),interval_detail::up(1/a.lo));};
 auto inverse=[](C d)->std::optional<C>{B n=d.re*d.re+d.im*d.im;if(!(n.lo>0))return std::nullopt;return coefficient_detail::conj(d)*C{B(interval_detail::down(1/n.hi),interval_detail::up(1/n.lo))};};
 auto absolute_upper=[](C a){const double x=std::max(std::abs(a.re.lo),std::abs(a.re.hi)),y=std::max(std::abs(a.im.lo),std::abs(a.im.hi));return interval_detail::up(std::hypot(x,y));};
 auto absolute_lower=[](C a){B n=a.re*a.re+a.im*a.im;return n.lo>0?std::max(0.,interval_detail::down(std::sqrt(n.lo))):0.;};
 const auto lenses=p.lenses();const auto masses=p.masses();
 const std::array<B,3> mass{B(1)-B(p.m1)-B(p.m2),B(p.m1),B(p.m2)};
 for(auto m:mass)if(!(m.lo>0))return {};
 const Complex phase=std::polar(1.,phi);
 const C phase_box{B(interval_detail::down(phase.real()-eps),interval_detail::up(phase.real()+eps)),B(interval_detail::down(phase.imag()-eps),interval_detail::up(phase.imag()+eps))};
 for(auto&z:roots)for(int step=0;step<16;++step){auto[k,d]=kappa(z,p);if(!(std::abs(d)>0))break;auto delta=(k-phase)/d;auto next=z-delta;if(!std::isfinite(next.real()+next.imag()))break;z=next;if(std::abs(delta)<4*std::numeric_limits<double>::epsilon()*(1+std::abs(z)))break;}
 std::vector<Disk> out;
 for(int i=0;i<6;++i){
  const Complex z=roots[i];const C center{B(z.real()),B(z.imag())};
  C k{},d{},mapped=center;std::array<double,3>distance{};
  for(int j=0;j<3;++j){
   const C difference=center-C{B(lenses[j].real()),B(lenses[j].imag())};
   auto inv=inverse(difference);if(!inv)return {};
   distance[j]=absolute_lower(difference);if(!(distance[j]>0))return {};
   k=k+C{mass[j]}*(*inv)*(*inv);d=d-C{B(2)*mass[j]}*(*inv)*(*inv)*(*inv);
   mapped=mapped-C{mass[j]}*coefficient_detail::conj(*inv);
  }
  const Complex derivative(d.re.lo+(d.re.hi-d.re.lo)*.5,d.im.lo+(d.im.hi-d.im.lo)*.5);
  if(!(std::abs(derivative)>0))return {};
  const Complex c=1./derivative;const C precondition{B(c.real()),B(c.imag())};
  const double cn=absolute_upper(precondition);
  const double phase_width=interval_detail::up(2*std::sin(half*.5)+eps);
  const double beta=(B(absolute_upper(precondition*(k-phase_box)))+B(cn)*B(phase_width)).hi;
  const double defect=absolute_upper(C{B(1)}-precondition*d);
  double limit=INFINITY;
  for(double a:distance)limit=std::min(limit,.45*a);
  for(int j=0;j<6;++j)if(i!=j)limit=std::min(limit,.45*std::abs(z-roots[j]));
  double radius=std::max(1.25*beta,8*std::numeric_limits<double>::epsilon()*(1+std::abs(z)));bool proved=false;
  for(int attempt=0;attempt<64 && radius<limit;++attempt,radius*=1.3){
   B q(defect);
   for(int j=0;j<3;++j){const double lower=interval_detail::down(distance[j]-radius);if(!(lower>0))return {};B n(lower);q=q+B(cn)*B(6)*mass[j]*B(radius)*reciprocal(n*n*n*n);}
   if(q.hi<1 && (B(beta)+q*B(radius)).hi<radius){proved=true;break;}
  }
  if(!proved)return {};
  const Complex w(mapped.re.lo+(mapped.re.hi-mapped.re.lo)*.5,mapped.im.lo+(mapped.im.hi-mapped.im.lo)*.5);
  B height(radius);
  for(int j=0;j<3;++j){B lower(interval_detail::down(distance[j]-radius));height=height+mass[j]*B(radius)*reciprocal(B(distance[j])*lower);}
  height=height+B(absolute_upper(mapped-C{B(w.real()),B(w.imag())}));
  if(!std::isfinite(height.hi))return {};
  out.push_back({z,w,radius,height.hi});
 }
 // The .45-separation proposal is not a certificate. Verify disk disjointness
 // with outward arithmetic before using degree six for completeness.
 for(int i=0;i<6;++i)for(int j=0;j<i;++j){
  C delta{B(out[i].z.real())-B(out[j].z.real()),B(out[i].z.imag())-B(out[j].z.imag())};
  if(!(absolute_lower(delta)>(B(out[i].r)+B(out[j].r)).hi))return {};
 }
 return out;
}
