#pragma once

#include "lcbinint/magnification/point_source_magnifier.hpp"
#include "lcbinint/magnification/finite_source_magnifier.hpp"
#include "lcbinint/model/lens_parameters.hpp"
#include "lcbinint/model/trajectory.hpp"
#include "lcbinint/obs/coordinates.hpp"
#include "lcbinint/types.hpp"

#include <limits>
#include <memory>

namespace lcbinint::model {

struct MagnificationExecutionPlan {
    magnification::FiniteSourceMethod method =
        magnification::FiniteSourceMethod::point_source;
    int resolution = 0;
    // Tolerances for the opt-in algebraic_boundary_auto request. NaN uses the
    // LightCurve's existing finite-source error budget.
    double algebraic_boundary_atol = std::numeric_limits<double>::quiet_NaN();
    double algebraic_boundary_rtol = std::numeric_limits<double>::quiet_NaN();
    // Clear shared binary caustic/seed/result caches once at the start of a
    // diagnostic light curve, so repeated benchmark calls measure cold input.
    bool clear_binary_epoch_caches_before = false;


};

class LensModel {
public:
    LensModel(
        LensParameters params,
        ComputationOptions options,
        std::shared_ptr<const obs::Site> site = nullptr);

    MagnificationResult magnification(double time) const;
    MagnificationResult magnification(
        double time, const MagnificationExecutionPlan& plan) const;

    // Evaluate a preplanned static-binary epoch from source coordinates that
    // are already in the internal lens frame.  This deliberately bypasses
    // the trajectory/orbit coordinate path used by magnification(time,...).
    MagnificationResult magnification_source(
        SourcePosition source, const MagnificationExecutionPlan& plan) const;

    // Produce engine-neutral finite-source geometry after all trajectory and
    // orbital transformations.  This is intentionally separate from the
    // magnification result so an external caller can consume a whole
    // trajectory's geometry in one call without root-solving.
    bool finite_source_geometry(
        double time,
        magnification::FiniteSourceGeometry& output) const;

private:
    MagnificationResult magnification_impl(
        double time, const MagnificationExecutionPlan* plan) const;
    LensParameters params_;
    ComputationOptions options_;
    Trajectory trajectory_;
    std::shared_ptr<const obs::Site> site_;
    double cos_theta_ = 1.0;
    double sin_theta_ = 0.0;
    std::shared_ptr<magnification::FiniteSourceMagnifier> finite_magnifier_;
    mutable magnification::PointSourceMagnifier point_magnifier_;
    mutable bool binary_epoch_caches_cleared_ = false;
};

} // namespace lcbinint::model
