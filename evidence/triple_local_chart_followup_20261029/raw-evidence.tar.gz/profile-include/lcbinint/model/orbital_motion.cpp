#include "lcbinint/model/orbital_motion.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>

namespace lcbinint::model {
namespace {

constexpr double kBranchEps = 1.0e-8;

double safe_sqrt(double value)
{
    return std::sqrt(std::max(0.0, value));
}

double dot(std::array<double, 3> lhs, std::array<double, 3> rhs)
{
    return lhs[0] * rhs[0] + lhs[1] * rhs[1] + lhs[2] * rhs[2];
}

std::array<double, 3> scale(std::array<double, 3> value, double factor)
{
    return {value[0] * factor, value[1] * factor, value[2] * factor};
}

std::array<double, 3> cross(std::array<double, 3> lhs, std::array<double, 3> rhs)
{
    return {
        lhs[1] * rhs[2] - lhs[2] * rhs[1],
        lhs[2] * rhs[0] - lhs[0] * rhs[2],
        lhs[0] * rhs[1] - lhs[1] * rhs[0],
    };
}

std::array<double, 3> normalize(std::array<double, 3> value)
{
    const double norm = safe_sqrt(dot(value, value));
    if (norm == 0.0 || !std::isfinite(norm)) {
        const double nan = std::numeric_limits<double>::quiet_NaN();
        return {nan, nan, nan};
    }
    return scale(value, 1.0 / norm);
}

double solve_kepler_newton(double mean_anomaly, double eccentricity)
{
    double eccentric_anomaly = mean_anomaly + eccentricity * std::sin(mean_anomaly);
    for (int i = 0; i < 10; ++i) {
        const double f = eccentric_anomaly - eccentricity * std::sin(eccentric_anomaly) -
                         mean_anomaly;
        const double fp = 1.0 - eccentricity * std::cos(eccentric_anomaly);
        const double delta = f / fp;
        eccentric_anomaly -= delta;
        if (std::abs(delta) <= 1.0e-13) {
            break;
        }
    }
    return eccentric_anomaly;
}

double orbital_reference_time(const LensParameters& params)
{
    return params.tfix != 0.0 ? params.tfix : params.t0;
}

struct KeplerGeometry {
    double ar = std::numeric_limits<double>::quiet_NaN();
    double smix = std::numeric_limits<double>::quiet_NaN();
    double sqsmix = std::numeric_limits<double>::quiet_NaN();
    double w11 = std::numeric_limits<double>::quiet_NaN();
    double w22 = std::numeric_limits<double>::quiet_NaN();
    double w33 = std::numeric_limits<double>::quiet_NaN();
    double w12 = std::numeric_limits<double>::quiet_NaN();
    double wt2 = std::numeric_limits<double>::quiet_NaN();
    double arm1 = std::numeric_limits<double>::quiet_NaN();
    double arm2 = std::numeric_limits<double>::quiet_NaN();
    double mean_motion = std::numeric_limits<double>::quiet_NaN();
    std::array<double, 3> z_axis{};
    std::array<double, 3> x_axis{};
    double x_norm = std::numeric_limits<double>::quiet_NaN();
    double eccentricity = std::numeric_limits<double>::quiet_NaN();
    bool valid = false;
};

KeplerGeometry make_kepler_geometry(
    double w1, double w2, double w3, double szs, double ar)
{
    KeplerGeometry out;
    if (!std::isfinite(w1) || !std::isfinite(w2) || !std::isfinite(w3)
        || !std::isfinite(szs) || !std::isfinite(ar) || ar <= 0.5) {
        return out;
    }

    out.ar = ar + kBranchEps;
    out.smix = 1.0 + szs * szs;
    out.sqsmix = std::sqrt(out.smix);
    out.w11 = w1 * w1;
    out.w22 = w2 * w2;
    out.w33 = w3 * w3;
    out.w12 = out.w11 + out.w22;
    out.wt2 = out.w12 + out.w33;
    out.arm1 = out.ar - 1.0;
    out.arm2 = 2.0 * out.ar - 1.0;
    if (!std::isfinite(out.wt2) || out.wt2 <= 0.0
        || !std::isfinite(out.smix) || !std::isfinite(out.arm2)
        || out.arm2 <= 0.0) {
        return out;
    }

    out.mean_motion = std::sqrt(out.wt2 / out.arm2 / out.smix) / out.ar;
    out.z_axis = normalize({-szs * w2, szs * w1 - w3, w2});
    out.x_axis = {
        -out.ar * out.w11 + out.arm1 * out.w22
            - out.arm2 * szs * w1 * w3 + out.arm1 * out.w33,
        -out.arm2 * w2 * (w1 + szs * w3),
        out.arm1 * szs * out.w12 - out.arm2 * w1 * w3
            - out.ar * szs * out.w33,
    };
    out.x_norm = safe_sqrt(dot(out.x_axis, out.x_axis));
    out.eccentricity = out.x_norm / (out.ar * out.sqsmix * out.wt2);
    out.valid = std::isfinite(out.mean_motion) && out.mean_motion > 0.0
        && std::isfinite(out.z_axis[0]) && std::isfinite(out.z_axis[1])
        && std::isfinite(out.z_axis[2])
        && std::isfinite(out.x_norm) && out.x_norm > 0.0
        && std::isfinite(out.eccentricity)
        && out.eccentricity >= 0.0 && out.eccentricity < 1.0;
    return out;
}

} // namespace

bool kepler_orbit_is_valid(
    double w1, double w2, double w3, double szs, double ar)
{
    return make_kepler_geometry(w1, w2, w3, szs, ar).valid;
}

OrbitalState circular_orbital_motion_3d(
    double time,
    double separation,
    double angle,
    double w1,
    double w2,
    double w3,
    double reference_time)
{
    const double w13_sq = w1 * w1 + w3 * w3;
    const double w13 = std::sqrt(w13_sq);
    const double w123 = std::sqrt(w13_sq + w2 * w2);

    double w_orb = w2;
    double inc = 0.0;
    double phi0 = 0.0;
    if (w13 > kBranchEps) {
        const double w3_eff = w3 > kBranchEps ? w3 : kBranchEps;
        w_orb = w3_eff * w123 / w13;
        const double cos_inc_arg = std::clamp(w2 * w3_eff / (w13 * w123), -1.0, 1.0);
        inc = std::acos(cos_inc_arg);
        phi0 = std::atan2(-w1 * w123, w3_eff * w13);
    }

    const double c_phi0 = std::cos(phi0);
    const double s_phi0 = std::sin(phi0);
    const double c_inc = std::cos(inc);
    const double s_inc = std::sin(inc);
    const double den0 = std::sqrt(c_phi0 * c_phi0 + c_inc * c_inc * s_phi0 * s_phi0);
    const double s_true = separation / den0;

    const double c_angle0 = std::cos(angle);
    const double s_angle0 = std::sin(angle);
    const double c_om = (c_phi0 * c_angle0 + c_inc * s_angle0 * s_phi0) / den0;
    const double s_om = (c_phi0 * s_angle0 - c_inc * c_angle0 * s_phi0) / den0;

    const double phi = w_orb * (time - reference_time) + phi0;
    const double c_phi = std::cos(phi);
    const double s_phi = std::sin(phi);
    const double den = std::sqrt(c_phi * c_phi + c_inc * c_inc * s_phi * s_phi);

    OrbitalState state;
    state.separation = s_true * den;
    const double sin_angle = (c_phi * s_om + c_inc * s_phi * c_om) / den;
    const double cos_angle = (c_phi * c_om - c_inc * s_phi * s_om) / den;
    state.angle = std::atan2(sin_angle, cos_angle);
    state.line_of_sight_separation = s_true * s_inc * s_phi;
    return state;
}

OrbitalState kepler_orbital_motion_3d(
    double time,
    double separation,
    double angle,
    double w1,
    double w2,
    double w3,
    double szs,
    double ar,
    double reference_time)
{
    struct PreparedOrbit {
        std::array<double, 7> key{};
        bool initialized = false;
        bool valid = false;
        double mean_motion = 0.0, eccentricity = 0.0, t_peri = 0.0;
        double semi_major_axis = 0.0, minor_axis_factor = 0.0;
        std::array<double, 3> x_axis{}, y_axis{};
    };
    // Only the anomaly changes with time. Exact keys avoid reusing geometry
    // across model proposals; thread-local storage keeps callers independent.
    thread_local PreparedOrbit prepared;
    const std::array<double, 7> key{w1, w2, w3, szs, ar, separation, reference_time};
    if (!prepared.initialized || prepared.key != key) {
        const auto geometry = make_kepler_geometry(w1, w2, w3, szs, ar);
        prepared = PreparedOrbit{};
        prepared.initialized = true;
        prepared.key = key;
        prepared.valid = geometry.valid;
        if (geometry.valid) {
            prepared.mean_motion = geometry.mean_motion;
            prepared.eccentricity = geometry.eccentricity;
            prepared.x_axis = scale(geometry.x_axis, 1.0 / geometry.x_norm);
            prepared.y_axis = cross(geometry.z_axis, prepared.x_axis);
            const double conu = (prepared.x_axis[0] + prepared.x_axis[2]*szs) / geometry.sqsmix;
            const double cos_e0 = std::clamp((conu + geometry.eccentricity) /
                (1.0 + geometry.eccentricity*conu), -1.0, 1.0);
            const double sign = (prepared.y_axis[0] + prepared.y_axis[2]*szs) > 0.0 ? 1.0 : -1.0;
            const double e0 = std::acos(cos_e0)*sign;
            const double sin_e0 = safe_sqrt(1.0-cos_e0*cos_e0)*sign;
            prepared.t_peri = reference_time -
                (e0-geometry.eccentricity*sin_e0)/geometry.mean_motion;
            prepared.semi_major_axis = geometry.ar*separation*geometry.sqsmix;
            prepared.minor_axis_factor = safe_sqrt(1.0-geometry.eccentricity*geometry.eccentricity);
        }
    }
    if (!prepared.valid) {
        const double nan = std::numeric_limits<double>::quiet_NaN();
        return {nan, nan, nan};
    }
    const double mean_motion = prepared.mean_motion;
    const double eccentricity = prepared.eccentricity;
    const double t_peri = prepared.t_peri;
    const double semi_major_axis = prepared.semi_major_axis;
    const auto& x_axis = prepared.x_axis;
    const auto& y_axis = prepared.y_axis;

    const double mean_anomaly = mean_motion * (time - t_peri);
    const double eccentric_anomaly = solve_kepler_newton(mean_anomaly, eccentricity);
    const double cos_e = std::cos(eccentric_anomaly);
    const double sin_e = std::sin(eccentric_anomaly);
    const double r0 = semi_major_axis * (cos_e - eccentricity);
    const double r1 = semi_major_axis * prepared.minor_axis_factor * sin_e;

    const double x0 = r0 * x_axis[0] + r1 * y_axis[0];
    const double x1 = r0 * x_axis[1] + r1 * y_axis[1];
    const double x2 = r0 * x_axis[2] + r1 * y_axis[2];

    OrbitalState state;
    state.separation = std::sqrt(x0 * x0 + x1 * x1);
    state.angle = angle + std::atan2(x1, x0);
    state.line_of_sight_separation = x2;
    return state;
}

OrbitalState orbital_state(const LensParameters& params, double time)
{
    const double reference_time = orbital_reference_time(params);
    switch (params.orbital_motion_mode) {
    case LCBI_ORBIT_CIRCULAR:
        return circular_orbital_motion_3d(
            time, params.sep, params.theta, params.g1, params.g2, params.g3,
            reference_time);
    case LCBI_ORBIT_KEPLER:
        return kepler_orbital_motion_3d(
            time, params.sep, params.theta, params.g1, params.g2, params.g3,
            params.lom_szs, params.lom_ar, reference_time);
    case LCBI_ORBIT_STATIC:
    default:
        return {params.sep, params.theta, 0.0};
    }
}

SourcePosition rotate_source_to_orbital_frame(SourcePosition source, double angle_delta)
{
    const double c = std::cos(angle_delta);
    const double s = std::sin(angle_delta);
    return {source.x * c + source.y * s, source.y * c - source.x * s};
}

} // namespace lcbinint::model
