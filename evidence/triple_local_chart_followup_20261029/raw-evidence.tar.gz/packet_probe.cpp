#include "lcbinint/magnification/triple_approximation.hpp"
#include <iostream>
#include <iomanip>
#include <cmath>
using namespace lcbinint;
int main(){int id,j;double s,q,sep,ang,q2,X,Y,rho;std::cout<<std::setprecision(17);while(std::cin>>id>>j>>s>>q>>sep>>ang>>q2>>X>>Y>>rho){double off=q*s/(1+q),den=1+q+q2;model::TripleLensGeometry g;g.masses={1/den,q/den,q2/den};g.lens_positions={SourcePosition{off,0},SourcePosition{-s/(1+q),0},SourcePosition{off-sep*std::cos(ang),-sep*std::sin(ang)}};magnification::PointSourceMagnifier solver;auto safety=solver.triple_safety_diagnostic(g,{X,Y});auto p=magnification::triple_approximation::point<true>(solver,g,{X,Y},4);auto h=magnification::triple_approximation::hex<true>(solver,g,{X,Y},rho,0.,4);std::cout<<"{\"case\":"<<id<<",\"point_valid\":"<<p.valid<<",\"images\":"<<p.images<<",\"point_mu\":"<<p.mu<<",\"point_error\":"<<6*safety.quadrupole_indicator*rho*rho<<",\"hex_mu\":"<<h.mu<<",\"hex_valid\":"<<h.valid<<",\"hex_error\":"<<h.error<<"}\n";}}
