from pathlib import Path
p=Path('src/lcbinint/magnification/finite_source_magnifier.cpp');s=p.read_text();Path('evidence/triple_local_chart_followup_20261029/finite_source_magnifier.before.cpp').write_text(s)
pos=s.index('    return out;\n}\n} // namespace\nFiniteSourceResult FiniteSourceMagnifier::algebraic_boundary_triple_mag(')
insert='''    if(!out.value.converged) {
        // A root cluster can be an artefact of the caustic polynomial frame.
        // Change only its geometric proof coordinates, then evaluate the
        // original physical point/hex packet including every image and IFT.
        // This is a final rescue after all integral routes have refused.
        static thread_local std::array<kernel::PreparedRegularSupport,2> alternate_clearance;
        const std::array<std::array<int,3>,2> orders{{{1,0,2},{2,0,1}}};
        for(std::size_t k=0;k<orders.size();++k) {
            const auto order=orders[k];
            const std::array<kernel::Complex,3> ordered{lenses[order[0]],lenses[order[1]],lenses[order[2]]};
            const auto proof=kernel::primary_frame(ordered,{source.x,source.y},rho,
                geometry.masses[order[1]],geometry.masses[order[2]]);
            const auto clear=alternate_clearance[k].caustic_clearance(proof.geometry,hex_distance);
            if(!(clear.first>hex_distance))continue;
            const auto hex=triple_approximation::hex<Gradient>(point,geometry,source,rho,
                limb_darkening_gamma(finite),clear.second);
            if(!hex.valid || hex.error>budget(hex.mu))continue;
            accept(hex.mu,hex.error,FiniteSourceMethod::hexadecapole,13,
                "triple hexadecapole and reframed certified caustic clearance");
            out.value.caustic_distance=clear.first;out.value.center_image_count=clear.second;
            if constexpr(Gradient){out.gradient=hex.gradient;out.gradient_valid=hex.gradient_valid;}
            break;
        }
    }
'''
s=s[:pos]+insert+s[pos:];p.write_text(s)
