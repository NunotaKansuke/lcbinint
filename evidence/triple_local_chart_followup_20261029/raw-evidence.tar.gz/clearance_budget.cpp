#include <iostream>
#include "lcbinint/magnification/algebraic_boundary/triple/integrator.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/regular_support.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/frame.hpp"
#include <iostream>
#include <iomanip>
#include <ctime>
using namespace lcbinint::algebraic_boundary::triple;
namespace rs=regular_support_detail;
int main(){int id,j;double s,q,sep,ang,q2,X,Y,rho;std::cout<<std::setprecision(17);while(std::cin>>id>>j>>s>>q>>sep>>ang>>q2>>X>>Y>>rho){double off=q*s/(1+q),den=1+q+q2;std::array<Complex,3> l{Complex(off,0),Complex(-s/(1+q),0),Complex(off,0)-sep*std::polar(1.,ang)};std::array<double,3> m{1/den,q/den,q2/den};for(auto o:std::array<std::array<int,3>,3>{{{0,1,2},{1,0,2},{2,0,1}}}){auto f=primary_frame({l[o[0]],l[o[1]],l[o[2]]},{X,Y},rho,m[o[1]],m[o[2]]);rs::Tree tree(f.geometry);double a=double(clock())/CLOCKS_PER_SEC;std::cerr<<"case "<<id<<" frame "<<o[0]<<"\n";auto clear=tree.clearance({f.geometry.X,f.geometry.Y},5*rho,65536);double dt=double(clock())/CLOCKS_PER_SEC-a;int old=0,now=0;std::cout<<"{\"case\":"<<id<<",\"frame\":"<<o[0]<<",\"old_centers\":"<<old<<",\"interval_centers\":"<<now<<",\"clearance\":"<<clear.first<<",\"count\":"<<clear.second<<",\"seconds\":"<<dt<<"}\n"<<std::flush;}}}
