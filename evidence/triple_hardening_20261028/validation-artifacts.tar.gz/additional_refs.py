import sys,json,subprocess,os,concurrent.futures,time,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;Q=P.parent/'triple_stress_expanded_20261028';cases=json.loads((P/'cases.json').read_text());D=P/'tighter-reference';D.mkdir(exist_ok=True)
a=json.loads((P/'comparison.json').read_text());selected=sorted(set(a['recovered_conditions'])|{r['case']for r in a['changed']}|{6,21,255,384,192,24,54,222,16,80,116,200})
(P/'additional-ref-selected.json').write_text(json.dumps(selected));jobs=[(i,e)for i in selected for e in ['MultiPoly','NoPoly']if not(Q/'tighter-reference'/f'{i:04d}-{e}.json').exists()]
def task(item):
 i,e=item;f=D/f'{i:04d}-{e}.json'
 if f.exists():return
 c=dict(cases[i],rtol=1e-7);inp=D/f'{i:04d}-{e}-input.json';inp.write_text(json.dumps(c))
 try:
  r=subprocess.run([sys.executable,str(P/'worker.py'),str(inp),e],capture_output=True,text=True,timeout=45,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'));z=json.loads(r.stdout)if r.returncode==0 else dict(classification='worker_exit',returncode=r.returncode,stderr=r.stderr)
 except Exception as exc:z=dict(classification='reference_failure',error=repr(exc))
 z.update(case=i,rtol=1e-7,input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest());f.write_text(json.dumps(z,indent=2));print(i,e,z['classification'],flush=True)
start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:list(pool.map(task,jobs))
(P/'additional-ref-complete.json').write_text(json.dumps(dict(jobs=len(jobs),selected=len(selected),elapsed=time.time()-start)))
