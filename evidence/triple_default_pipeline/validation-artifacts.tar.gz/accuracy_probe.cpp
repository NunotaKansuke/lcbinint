#include "lcbinint/magnification/algebraic_boundary/triple/integrator.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/regular_support.hpp"
#include <iostream>
#include <iomanip>
using namespace lcbinint::algebraic_boundary::triple;
int main(){
 for(auto input:std::array<std::array<double,3>,3>{{{{.0840625,.075,10.347258346635238}},{{.125,.3,5.846141393365811}},{{.121484375,.3,5.835729710839479}}}}){
  Geometry p{input[0],.15,input[1],.2,.08,1.,-.4,.6};IntegrationOptions o;o.absolute_tolerance=0;o.relative_tolerance=1e-4;
  PreparedRegularSupport prep;auto plan=prep.plan(p,1e-4);
  auto v=integrate(p,0,o,&plan);std::cout<<"omitted "<<plan.excluded_images.size()<<" "<<plan.bounded_component_value<<" "<<plan.bounded_component_error<<"\n";plan=prep.plan(p,1e-4,o.event_box_budget,false);auto full=integrate(p,0,o,&plan);auto g=integrate<true>(p,0,o,&plan);
  for(auto* z:std::array<IntegrationDiagnostics*,3>{&v,&full,&g})std::cout<<std::setprecision(17)<<input[0]<<" "<<z->magnification<<" "<<z->error_estimate<<" "<<std::abs(z->magnification/input[2]-1)<<" "<<z->converged<<" "<<z->value_evaluations<<" "<<z->reason<<"\n";
 }
}
