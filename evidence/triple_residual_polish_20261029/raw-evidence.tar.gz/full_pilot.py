import os,sys,json,subprocess,concurrent.futures,time
from pathlib import Path
P=Path(__file__).resolve().parent;B=P.parent/'triple_final_polish_20261029';D=P/'full-pilot';D.mkdir(exist_ok=True)
if '--worker'in sys.argv:
 sys.path.insert(0,str(B));import worker_annulus as w
 w.resource.setrlimit(w.resource.RLIMIT_CPU,(20,22));c=json.loads((P/'cases.json').read_text())[int(sys.argv[2])];print(json.dumps(w.run(c,sys.argv[3]),allow_nan=False),flush=True);sys.exit()
selected=[419,448];start=time.time()
def task(job):
 i,e=job
 try:
  r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',str(i),e],capture_output=True,text=True,timeout=45,env=dict(os.environ,TRIPLE_BUILD=str(P/'full-package'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'));z=json.loads(r.stdout)if r.returncode==0 else dict(classification='worker_exit',returncode=r.returncode,stderr=r.stderr[-2000:])
 except Exception as exc:z=dict(classification='harness_failure',error=repr(exc))
 (D/f'{i:04d}-{e}.json').write_text(json.dumps(z,indent=2));print(i,e,z['classification'],z.get('info',{}).get('finite_source_method'),flush=True);return z
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:
 for n,z in enumerate(pool.map(task,[(i,e)for i in selected for e in ['value','gradient']]),1):(P/'full-pilot-status.json').write_text(json.dumps(dict(completed=n,total=2*len(selected),elapsed=time.time()-start)))
