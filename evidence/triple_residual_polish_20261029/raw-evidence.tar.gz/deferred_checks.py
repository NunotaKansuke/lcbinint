import sys,subprocess,json,time,os
from pathlib import Path
P=Path(__file__).resolve().parent;results={}
for name in ['deferred_regression_tests','deferred_invariants']:
 with open(P/(name+'.log'),'w')as f:r=subprocess.run([sys.executable,str(P/(name+'.py'))],stdout=f,stderr=subprocess.STDOUT)
 results[name]=r.returncode
(P/'deferred-checks-status.json').write_text(json.dumps(dict(state='PASS'if not any(results.values())else'FAIL',results=results,finished=time.time()),indent=2))
