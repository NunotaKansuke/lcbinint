import os,json,time,sys
from pathlib import Path
P=Path(__file__).resolve().parent
while json.loads((P/'full-status.json').read_text())['state']=='RUNNING':time.sleep(1)
os.execv(sys.executable,[sys.executable,str(P/'index_run.py')])
