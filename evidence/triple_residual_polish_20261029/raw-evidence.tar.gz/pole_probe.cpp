#include "lcbinint/magnification/point_source_magnifier.hpp"
#include "lcbinint/model/triple_lens_geometry.hpp"
#include <complex>
#include <iostream>
#include <iomanip>
#include <limits>
#include <vector>
using namespace lcbinint;using namespace lcbinint::magnification;
using C=std::complex<long double>;
struct SafeDouble{double value;};
std::ostream& operator<<(std::ostream& out,SafeDouble x){if(std::isfinite(x.value))return out<<x.value;return out<<"null";}
struct Eval{C f,k;long double det,residual;};
Eval evaluate(const model::TripleLensGeometry& g,SourcePosition s,int owner,C delta){
 const auto o=g.lens_positions[owner];C f=C((long double)o.x-s.x,(long double)o.y-s.y)+delta,k{};
 for(int j=0;j<3;++j){const auto z=g.lens_positions[j];const C d=C((long double)o.x-z.x,(long double)o.y-z.y)+delta;const C v=1.L/std::conj(d);f-=(long double)g.masses[j]*v;k+=(long double)g.masses[j]*v*v;}
 return {f,k,1-std::norm(k),std::abs(f)};
}
int main(){double t0,u0,tE,alpha,s,q,q2,sep,ang,rho,limb,tol;int n;
 std::cin>>t0>>u0>>tE>>alpha>>s>>q>>q2>>sep>>ang>>rho>>limb>>tol>>n;
 const auto g=model::make_triple_lens_geometry_vbm(s,q,sep,ang,q2);PointSourceMagnifier solver;std::cout<<std::setprecision(17);
 for(int j=0;j<n;++j){double t;std::cin>>t;const double tau=(t-t0)/tE;SourcePosition src{tau*std::cos(alpha)-u0*std::sin(alpha),tau*std::sin(alpha)+u0*std::cos(alpha)};const auto safety=solver.triple_safety_diagnostic(g,src);const auto images=solver.triple_image_candidates_cached(g,src);
 std::cout<<"{\"epoch\":"<<j<<",\"source\":["<<src.x<<","<<src.y<<"],\"old_count\":"<<safety.image_count<<",\"old_mu\":"<<SafeDouble{safety.magnification}<<",\"candidates\":[";
 for(std::size_t k=0;k<images.size();++k){if(k)std::cout<<",";const auto a=images[k];std::cout<<"{\"position\":["<<a.position.x<<","<<a.position.y<<"],\"residual\":"<<SafeDouble{a.residual}<<",\"physical\":"<<a.physical<<"}";}
 std::cout<<"],\"local\":[";
 for(int owner=0;owner<3;++owner){if(owner)std::cout<<",";const auto o=g.lens_positions[owner];C D=C(src.x,src.y)-C(o.x,o.y);bool distinct=true;for(int k=0;k<3;++k)if(k!=owner){const auto a=g.lens_positions[k];const C separation=C((long double)o.x-a.x,(long double)o.y-a.y);if(separation==C{}){distinct=false;break;}D+=(long double)g.masses[k]/std::conj(separation);}
 const long double distance=std::abs(D),mass=g.masses[owner];if(!distinct||!(distance>0&&mass>0)){std::cout<<"null";continue;}
 C delta=(-2*mass/(distance+std::hypot(distance,2*std::sqrt(mass))))*D/distance;int iter=0;
 for(;iter<32;++iter){const auto v=evaluate(g,src,owner,delta);if(!std::isfinite(v.residual)||!std::isfinite(v.det)||v.det==0)break;const C step=(v.f-v.k*std::conj(v.f))/v.det;if(!std::isfinite(std::abs(step)))break;delta-=step;if(std::abs(step)<16*std::numeric_limits<long double>::epsilon()*(std::abs(delta)+1e-100L))break;}
 // Keep a double displacement without adding it to the large pole position.
 const C retained((double)delta.real(),(double)delta.imag());const auto local=evaluate(g,src,owner,retained);const double x=double((long double)o.x+retained.real()),y=double((long double)o.y+retained.imag());const auto projected=evaluate(g,src,owner,C((long double)x-o.x,(long double)y-o.y));bool duplicate=false;for(const auto&a:images)if(a.physical&&std::hypot(x-a.position.x,y-a.position.y)<1e-8)duplicate=true;
 if(!std::isfinite(local.residual)||!std::isfinite(projected.residual)||!std::isfinite(local.det)||local.det==0){std::cout<<"null";continue;}
 std::cout<<"{\"lens\":"<<owner<<",\"offset\":["<<double(retained.real())<<","<<double(retained.imag())<<"],\"local_residual\":"<<double(local.residual)<<",\"projected_residual\":"<<double(projected.residual)<<",\"determinant\":"<<double(local.det)<<",\"mu\":"<<double(1/std::abs(local.det))<<",\"duplicate\":"<<duplicate<<",\"iterations\":"<<iter<<"}";
 }
 std::cout<<"]}\n";
 }
}
