import json,time,os,sys
from pathlib import Path
P=Path(__file__).resolve().parent
def status(path):
 while True:
  try:return json.loads(path.read_text())
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(.1)
while not(P/'deferred-checks-status.json').exists() or not(P/'deferred-status.json').exists():time.sleep(1)
while status(P/'deferred-status.json')['state']=='RUNNING':time.sleep(1)
if status(P/'deferred-checks-status.json')['state']!='PASS':raise RuntimeError('final checks failed')
os.execv(sys.executable,[sys.executable,str(P/'timing_deferred.py')])
