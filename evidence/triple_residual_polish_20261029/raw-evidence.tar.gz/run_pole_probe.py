import json,subprocess,resource,os,hashlib,concurrent.futures
from pathlib import Path
P=Path(__file__).resolve().parent;B=P.parent/'triple_final_polish_20261029';cases=json.loads((B/'cases.json').read_text());failed=json.loads((B/'remaining-failures.json').read_text())['rows'];selected=sorted({r['case']for r in failed}|{135,189,314,337,361,431});D=P/'pole-witnesses';D.mkdir(exist_ok=True)
def limits():
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CPU,(10,12));os.sched_setaffinity(0,{1,2})
def run(i):
 c=cases[i];p=c['params'];vals=[p[k]for k in ['t0','u0','tE','alpha','s','q','q2','sep2','ang','rho']]+[c['limb'],c['rtol'],len(c['epochs'])]+c['epochs'];data=' '.join(map(str,vals));(D/f'{i:04d}.input').write_text(data)
 try:
  r=subprocess.run([str(P/'pole-probe')],input=data,text=True,capture_output=True,timeout=20,preexec_fn=limits);(D/f'{i:04d}.jsonl').write_text(r.stdout);z=dict(case=i,returncode=r.returncode,stderr=r.stderr,input_sha256=hashlib.sha256(data.encode()).hexdigest());rows=[json.loads(line)for line in r.stdout.splitlines()];z['recovered']=[dict(epoch=row['epoch'],lens=w['lens'],local_residual=w['local_residual'],projected_residual=w['projected_residual'])for row in rows if row['old_count']<4 for w in row['local']if w is not None and not w['duplicate']and w['determinant']<0 and w['local_residual']<=1e-7];print(i,z['recovered'],flush=True)
 except Exception as exc:z=dict(case=i,error=repr(exc))
 (D/f'{i:04d}-status.json').write_text(json.dumps(z,indent=2))
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(run,selected))
