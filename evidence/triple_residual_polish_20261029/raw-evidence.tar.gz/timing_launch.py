import json,time,os,sys
from pathlib import Path
P=Path(__file__).resolve().parent
def status(path):
 while True:
  try:return json.loads(path.read_text())
  except (FileNotFoundError,json.JSONDecodeError):time.sleep(.1)
while not(P/'final-checks-status.json').exists() or not(P/'final-status.json').exists():time.sleep(1)
while status(P/'final-status.json')['state']=='RUNNING':time.sleep(1)
if status(P/'final-checks-status.json')['state']!='PASS':raise RuntimeError('final checks failed')
os.execv(sys.executable,[sys.executable,str(P/'timing_final.py')])
