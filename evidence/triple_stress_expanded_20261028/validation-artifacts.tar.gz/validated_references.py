import json,collections
from pathlib import Path
P=Path(__file__).resolve().parent;cases=json.loads((P/'cases.json').read_text());special={}
for filename,points in [('independent-ld.json',{855:1,955:1}),('independent-ld-1510.json',{1510:2})]:
 a=json.loads((P/filename).read_text())
 for i,j in points.items():
  vals=[];noise=[]
  for method in ['Multipoly','Nopoly']:
   r=sorted([x for x in a if x['case']==i and x['method']==method],key=lambda x:x['n']);vals.append(r[-1]['mu']);noise.append(abs(r[-1]['mu']-r[-2]['mu']))
  special[(i,j)]=dict(values=vals,quadrature_change=max(noise),source=filename)
rows=[];uncertain=[];failed=[]
for i,c in enumerate(cases):
 refs=[]
 for e in ['MultiPoly','NoPoly']:
  f=P/'tighter-reference'/f'{i:04d}-{e}.json'
  if f.exists():
   d=json.loads(f.read_text())
   if d['classification']=='ok':refs.append(d)
   else:failed.append(dict(case=i,engine=e,classification=d['classification'],returncode=d.get('returncode')))
 if len(refs)!=2:continue
 for e in ['value','gradient']:
  d=json.loads((P/'chart-fixed-rows'/f'{i:04d}-{e}.json').read_text())
  if 'mu'not in d:continue
  for j,(a,b,z)in enumerate(zip(d['mu'],refs[0]['mu'],refs[1]['mu'])):
   if a is None or b is None or z is None or min(b,z)<=0 or d['status'][j]!=0:continue
   source='VBM RelTol=1e-7';noise=0.
   if (i,j)in special:
    s=special[(i,j)];b,z=s['values'];noise=s['quadrature_change'];source='independent LD integral of VBM uniform disks'
   spread=abs(b/z-1)
   row=dict(case=i,index=j,engine=e,native=a,reference_values=[b,z],relative_error=max(abs(a/b-1),abs(a/z-1)),reference_spread=spread,reference_quadrature_change=noise,reference_source=source,requested=c['rtol'])
   row['ratio']=row['relative_error']/c['rtol']
   if spread>c['rtol']*.1:uncertain.append(row)
   else:rows.append(row)
r=dict(comparisons=len(rows),source_points=len({(x['case'],x['index'])for x in rows}),native_conditions=len({x['case']for x in rows}),maximum_ratio=max(x['ratio']for x in rows),maximum_relative_error=max(x['relative_error']for x in rows),exceedances=[x for x in rows if x['ratio']>1],ambiguous_reference_points=uncertain,reference_engine_failures=failed,independent_ld_overrides=[dict(case=i,index=j,**v)for(i,j),v in special.items()],largest=sorted(rows,key=lambda x:x['ratio'],reverse=True)[:20]);(P/'validated-reference-summary.json').write_text(json.dumps(r,indent=2));(P/'validated-reference-comparisons.json').write_text(json.dumps(rows,indent=2));print({k:v for k,v in r.items()if k not in ['ambiguous_reference_points','reference_engine_failures','largest']});print('ambiguous',len(uncertain),'reference engine failures',len(failed))
