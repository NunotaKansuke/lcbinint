import json,collections,statistics,math,hashlib,os
from pathlib import Path
P=Path(__file__).resolve().parent;cases=json.loads((P/'cases.json').read_text());counts=collections.defaultdict(collections.Counter);families=collections.defaultdict(lambda:collections.defaultdict(collections.Counter));comparisons=[];timing=collections.defaultdict(list);bad=[];ref_fail=[]
for i,c in enumerate(cases):
 data={}
 for e in ['value','gradient','SinglePoly','MultiPoly','NoPoly']:
  f=P/os.environ.get('SUMMARY_NATIVE_ROWS','rows')/f'{i:04d}-{e}.json' if e in ['value','gradient'] else P/'rows'/f'{i:04d}-{e}.json'
  if not f.exists():continue
  d=json.loads(f.read_text());data[e]=d;counts[e][d['classification']]+=1;families[c['family']][e][d['classification']]+=1
 for e in ['value','gradient']:
  if e not in data or 'mu'not in data[e]:continue
  refs=[]
  for re in ['MultiPoly','NoPoly']:
   f=P/'tighter-reference'/f'{i:04d}-{re}.json'
   if f.exists():
    d=json.loads(f.read_text())
    if d['classification']=='ok':refs.append(d)
    else:ref_fail.append([i,re,d['classification']])
  if len(refs)==2:
   for j,(a,b,d)in enumerate(zip(data[e]['mu'],refs[0]['mu'],refs[1]['mu'])):
    if a is None or b is None or d is None or min(b,d)<=0:continue
    status=data[e].get('status',[None]*len(data[e]['mu']))[j];spread=abs(b/d-1);error=max(abs(a/b-1),abs(a/d-1));x=dict(case=i,engine=e,index=j,status=status,error=error,spread=spread,rtol=c['rtol'],ratio=error/c['rtol'],mu=a,MultiPoly=b,NoPoly=d);comparisons.append(x)
    if status==0 and error>c['rtol'] and spread<c['rtol']*.1:bad.append(x)
 if 'value'in data and data['value']['classification']=='ok':
  for e in ['SinglePoly','MultiPoly','NoPoly','gradient']:
   if e in data and data[e]['classification']=='ok'and 'cpu_seconds'in data[e]and data['value']['cpu_seconds']>0:timing[e].append(data[e]['cpu_seconds']/data['value']['cpu_seconds'])
meta={}
for name in ['coordinates','invariants','permutation']:
 f=P/f'{name}.json'
 if f.exists():
  rows=json.loads(f.read_text());meta[name]={'conditions':len(rows),'exceptions':sum('error'in x for x in rows)}
  if name=='coordinates':meta[name].update(success=sum('ok'in x for x in rows),max_relative=max(x.get('relative_difference',0)for x in rows))
  if name=='invariants':meta[name].update(max_value_relative=max(c['value_relative']for x in rows for c in x.get('checks',{}).values()),max_gradient_scaled=max(c['gradient_scaled']for x in rows for c in x.get('checks',{}).values()))
  if name=='permutation':meta[name].update(max_relative=max((x[n]['difference']for x in rows for n in ['primary','secondary']if n in x),default=0),failures=[dict(case=x['case'],kind=n,relative=x[n]['difference'])for x in rows for n in ['primary','secondary']if n in x and x[n]['difference']>cases[x['case']]['rtol'] and all(t==0 for t in x[n]['status']+x.get('status',[]))])
r=dict(counts={k:dict(v)for k,v in counts.items()},families={k:{e:dict(v)for e,v in fam.items()}for k,fam in families.items()},tighter_comparisons=len(comparisons),tighter_valid_comparisons=sum(x['status']==0 for x in comparisons),tighter_max_ratio=max((x['ratio']for x in comparisons if x['status']==0 and x['spread']<x['rtol']*.1),default=0),candidate_false_successes=bad,reference_failures=ref_fail,metamorphic=meta,timing_raw_cpu_ratio={e:dict(n=len(v),median=statistics.median(v),p10=float(sorted(v)[len(v)//10]),p90=float(sorted(v)[int(len(v)*.9)]))for e,v in timing.items()if v})
r['native_rows']=os.environ.get('SUMMARY_NATIVE_ROWS','rows')
(P/os.environ.get('SUMMARY_FILENAME','summary.json')).write_text(json.dumps(r,indent=2));print(json.dumps({k:v for k,v in r.items()if k not in ['families','reference_failures']},indent=2))
