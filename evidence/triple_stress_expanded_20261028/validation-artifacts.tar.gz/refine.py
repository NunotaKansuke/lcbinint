import json,sys,subprocess,os
from pathlib import Path
P=Path(__file__).resolve().parent;cases=json.loads((P/'cases.json').read_text());out=[]
for i in [698,708,709]:
 for tol in [1e-4,1e-5,1e-7,1e-8]:
  for e in ['value','gradient','MultiPoly','NoPoly']:
   if tol<1e-5 and e in ['value','gradient']:continue
   c=dict(cases[i],rtol=tol,epochs=[cases[i]['epochs'][1]]);inp=P/f'refine-{i}-{tol}.json';inp.write_text(json.dumps(c));r=subprocess.run([sys.executable,str(P/'worker.py'),str(inp),e],capture_output=True,text=True,timeout=45,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
   try:z=json.loads(r.stdout)
   except Exception:z={'classification':'worker_exit','stderr':r.stderr,'returncode':r.returncode}
   out.append(dict(case=i,rtol=tol,engine=e,result=z));(P/'refine-contact2.json').write_text(json.dumps(out,indent=2));print(i,tol,e,z.get('mu',z.get('classification')),flush=True)
