from pathlib import Path
P=Path(__file__).resolve().parent
s=(P/'run.py').read_text().replace("engines=['value','gradient','SinglePoly','MultiPoly','NoPoly']","engines=['value','gradient']").replace("os.environ.get('EXPANDED_ROWS','rows')","os.environ.get('EXPANDED_ROWS','chart-fixed-rows')").replace("('pilot-status.json'if '--pilot'in sys.argv else 'status.json')","('native-pilot-status.json'if '--pilot'in sys.argv else 'native-fixed-status.json')")
exec(compile(s,str(P/'run.py'),'exec'))
