import sys,json,subprocess,os,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;D=P/'neighborhood-before';D.mkdir(exist_ok=True);rows=json.loads((P/'chart-neighborhood-refined.json').read_text())
for r in rows:
 i=r['case'];inp=D/f'{i:02d}-input.json';inp.write_text(json.dumps(r['condition']));a=subprocess.run([sys.executable,str(P/'worker.py'),str(inp),'gradient'],capture_output=True,text=True,timeout=45,env=dict(os.environ,TRIPLE_BUILD=str(P/'api-fixed-package'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
 z=json.loads(a.stdout)if a.returncode==0 else dict(returncode=a.returncode,stderr=a.stderr);z['input_sha256']=hashlib.sha256(inp.read_bytes()).hexdigest();(D/f'{i:02d}.json').write_text(json.dumps(z,indent=2));print(i,z.get('classification'),flush=True)
