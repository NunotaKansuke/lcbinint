import os,sys,json,time,math,statistics,subprocess,resource
from pathlib import Path
P=Path(__file__).resolve().parent
if '--worker'in sys.argv:
 os.sched_setaffinity(0,{0});resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_CPU,(30,32));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));import VBMicrolensing as V
 i=int(sys.argv[2]);engine=sys.argv[3];c=json.loads((P/'cases.json').read_text())[i];p=c['params'];vp=[math.log(p[k])if k in ['s','q','rho','tE','sep2','q2']else p[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']];v=V.VBMicrolensing();v.SetMethod(getattr(v.Method,dict(SinglePoly='Singlepoly',MultiPoly='Multipoly',NoPoly='Nopoly')[engine]));v.Tol=0.;v.RelTol=c['rtol'];v.a1=c['limb'];v.a2=0.;v.SetLDprofile(v.LDlinear);a=time.thread_time();z=v.TripleLightCurve(vp,c['epochs']);first=time.thread_time()-a
 for _ in range(2):v.TripleLightCurve(vp,c['epochs'])
 samples=[]
 for _ in range(15):
  a=time.thread_time();z=v.TripleLightCurve(vp,c['epochs']);samples.append(time.thread_time()-a)
 mu=list(z[0]);print(json.dumps(dict(case=i,engine=engine,first=first,warm=statistics.median(samples),samples=samples,mu=mu,valid=all(math.isfinite(x)and x>0 for x in mu))),flush=True);sys.exit()
D=P/'controlled-vbm-timing';D.mkdir(exist_ok=True);rows=[]
for i in [192,24,54,222,16,80,116,200]:
 for e in ['SinglePoly','MultiPoly','NoPoly']:
  try:
   r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',str(i),e],capture_output=True,text=True,timeout=45,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'));z=json.loads(r.stdout)if r.returncode==0 else dict(case=i,engine=e,returncode=r.returncode,stderr=r.stderr)
  except Exception as exc:z=dict(case=i,engine=e,error=repr(exc))
  (D/f'{i:04d}-{e}.json').write_text(json.dumps(z,indent=2));rows.append(z);(P/'controlled-vbm-timing.json').write_text(json.dumps(rows,indent=2));print(i,e,z.get('warm',z.get('returncode',z.get('error'))),flush=True)
