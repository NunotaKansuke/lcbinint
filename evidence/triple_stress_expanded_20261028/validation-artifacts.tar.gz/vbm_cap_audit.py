import subprocess,json,math,resource,os
from pathlib import Path
P=Path(__file__).resolve().parent;D=P/'vbm-audit';cs=json.loads((P/'cases.json').read_text());out=[]
def limits():
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_CPU,(20,22));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
for i in [855,955]:
 c=cs[i];p=c['params'];vp=[math.log(p[k])if k in ['s','q','rho','tE','sep2','q2']else p[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']];data=' '.join(map(repr,vp+[0.]))+'\n';(D/f'{i}.input').write_text(data)
 for tol in [1e-7,1e-8]:
  for cap in [100,300,1000]:
   for method in [0,1]:
    args=[str(D/'probe'),str(tol),str(c['limb']),str(cap),str(method)]
    try:
     r=subprocess.run(args,input=data,text=True,capture_output=True,timeout=45,preexec_fn=limits);z=json.loads(r.stdout)if r.returncode==0 else dict(returncode=r.returncode,stderr=r.stderr)
    except Exception as e:z=dict(error=repr(e))
    out.append(dict(case=i,tolerance=tol,cap=cap,method=method,result=z));(D/'cap-audit.json').write_text(json.dumps(out,indent=2));print(i,tol,cap,method,z,flush=True)
