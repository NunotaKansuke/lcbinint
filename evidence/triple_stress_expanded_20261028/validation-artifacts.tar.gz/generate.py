import sys,json,math,random,hashlib
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent;R=P.parent.parent
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];sys.path.insert(0,str(P/'baseline-build'));import lcbinint as lc
rng=random.Random(2026102802);cases=[];geometries=[]
def add(family,p,ts,limb,tol,**meta):cases.append(dict(name=f'{family}-{len(cases):04d}',family=family,params=p,epochs=ts,limb=limb,rtol=tol,**meta))
def base():return dict(t0=0.,u0=.2,tE=1.,alpha=.3,s=1.,q=.2,q2=.08,sep2=.7,ang=2.1,rho=.01)
for i in range(400):
 p=dict(t0=rng.uniform(-3,3),u0=rng.uniform(-2,2),tE=10**rng.uniform(-1,1),alpha=rng.uniform(-math.pi,math.pi),s=10**rng.uniform(-1.3,1.3),q=10**rng.uniform(-7,2),q2=10**rng.uniform(-7,2),sep2=10**rng.uniform(-1.3,1.3),ang=rng.uniform(-math.pi,math.pi),rho=10**rng.uniform(-5,-.1))
 ts=[p['t0']+p['tE']*x for x in [-3,-1,-.25,0,.25,1,3]];add('wide_random',p,ts,[0.,.5,1.][i%3],[1e-3,1e-4][i%2])
for i in range(120):
 p=base();p.update(s=[.01,.1,1.,10.,100.][i%5],q=[1e-8,1e-4,1.,1e4][i%4],q2=[1e-7,.01,1.,100.][(i//4)%4],rho=[1e-5,.003,.1,1.][(i//7)%4],ang=[0.,1e-10,math.pi,math.pi-1e-8,math.pi/3,-math.pi/3][i%6],alpha=rng.uniform(-math.pi,math.pi),u0=[.001,.1,.5][i%3])
 p['sep2']=p['s']*([.5,1+1e-6,1+.001,1.7][(i//3)%4]);add('near_collinear_or_clustered',p,[-1.,-.2,0.,.2,1.],[0.,.5,1.][i%3],[1e-3,1e-4][i%2])
for i in range(48):
 p=base();p.update(q=10**rng.uniform(-7,3),q2=10**rng.uniform(-7,3),s=10**rng.uniform(-1,1),sep2=10**rng.uniform(-1,1),ang=rng.uniform(-math.pi,math.pi),rho=0.,u0=rng.uniform(-1,1),alpha=rng.uniform(-math.pi,math.pi))
 add('point_source',p,[-1.5,-.4,0.,.4,1.5],0.,1e-4)
# Geometry samples only locate challenging sources. They are not routing proofs.
for i in range(24):
 p=base();p.update(s=10**rng.uniform(-.5,.5),q=10**rng.uniform(-4,.5),q2=10**rng.uniform(-4,.5),sep2=10**rng.uniform(-.5,.5),ang=rng.uniform(-math.pi,math.pi),alpha=rng.uniform(-math.pi,math.pi))
 model=lc.LightCurve(lens='triple',param_type='vbm',options=lc.Options(caustic_bins=128));curves=model.caustics(p);branches=[np.column_stack([np.asarray(x),np.asarray(y)])for x,y in zip(curves.x,curves.y)if len(x)>4]
 allpoints=np.concatenate(branches);geometries.append(dict(params=p,branches=[b.tolist()for b in branches]))
 selected=[]
 for direction in [[1,0],[0,1],[-1,0],[0,-1]]:
  b=max(branches,key=lambda x:float(np.max(x@direction)));j=int(np.argmax(b@direction));tangent=b[(j+1)%len(b)]-b[(j-1)%len(b)];norm=np.linalg.norm(tangent)
  if norm==0:tangent=np.array([1.,0.]);norm=1.
  normal=np.array([-tangent[1],tangent[0]])/norm;selected.append((b[j],normal))
 for k,(center,normal)in enumerate(selected):
  for rho in [.001,.03]:
   for offset in [-1.001,-.999,0.,.999,1.001]:
    q=dict(p,rho=rho);source=complex(*(center+rho*offset*normal));rot=source*complex(math.cos(q['alpha']),-math.sin(q['alpha']));q['t0']=-rot.real*q['tE'];q['u0']=rot.imag
    add('sampled_caustic_contact',q,[-rho*.01,0.,rho*.01],[0.,.5,1.][(i+k)%3],[1e-3,1e-4][(i+k)%2],geometry_index=i,caustic_sample=center.tolist(),normal=normal.tolist(),offset=offset)
(P/'cases.json').write_text(json.dumps(cases,indent=2,allow_nan=False));(P/'caustic-samples.json').write_text(json.dumps(geometries,allow_nan=False));print('conditions',len(cases),'epochs',sum(len(c['epochs'])for c in cases),flush=True)
