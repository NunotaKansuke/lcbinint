import os,sys,json,hashlib,subprocess,shutil,platform,time,difflib,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent;R=P.parent.parent
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
assert json.loads((P/'native-fixed-status.json').read_text())['completed']==3056
assert json.loads((P/'status.json').read_text())['completed']==7640
assert json.loads((P/'test-build-status.json').read_text())['state']=='PASS'
assert not json.loads((P/'validated-reference-summary.json').read_text())['exceedances']
assert not json.loads((P/'process-audit.json').read_text())['active_campaign_processes']
assert '37 passed'in(P/'chart-regression.log').read_text()
old=(P/'initial-dirty.patch').read_text();new=subprocess.check_output(['git','diff','--binary'],cwd=R,text=True)
changed={'a/python/bind_lc.cpp','a/src/lcbinint/magnification/algebraic_boundary/triple/patterson_stream.hpp'}
def other(s):return ''.join('diff --git '+b for b in s.split('diff --git ')[1:]if b.split(' ',1)[0]not in changed)
assert other(old)==other(new),'unrelated tracked diff changed'
(P/'preservation-final.json').write_text(json.dumps(dict(other_tracked_diff_unchanged=True,old_filtered_sha=hashlib.sha256(other(old).encode()).hexdigest(),new_filtered_sha=hashlib.sha256(other(new).encode()).hexdigest()),indent=2))
source_files=list((R/'src/lcbinint/magnification/algebraic_boundary/triple').glob('*.hpp'))+[R/'python/bind_lc.cpp',R/'python/bind_triple_algebraic.cpp',R/'src/lcbinint/magnification/point_source_magnifier.cpp',R/'src/lcbinint/magnification/finite_source_magnifier.cpp',R/'src/lcbinint/model/triple_lens_geometry.cpp',R/'tests/regression/test_triple_expanded_contract.py']
for f in source_files:
 dst=P/'final-source'/f.relative_to(R);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst)
patch=subprocess.check_output(['git','diff','--','python/bind_lc.cpp'],cwd=R,text=True)
f=R/'src/lcbinint/magnification/algebraic_boundary/triple/patterson_stream.hpp';name=str(f.relative_to(R));patch+=''.join(difflib.unified_diff((P/'before-chart-width.hpp').read_text().splitlines(True),f.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
f=R/'tests/regression/test_triple_expanded_contract.py';patch+=''.join(difflib.unified_diff([],f.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+str(f.relative_to(R))))
(P/'task-only.patch').write_text(patch)
packages={}
for name in ['baseline-build','api-fixed-package','chart-fixed-package']:
 f=P/name/'lcbinint/_lcbinint.cpython-310-x86_64-linux-gnu.so';packages[name]=sha(f)
assert packages['chart-fixed-package']==json.loads((P/'native-fixed-status.json').read_text())['native_sha256']
prov=dict(time=time.time(),host=platform.node(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),branch=subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip(),python=sys.version,compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],resource_budget=dict(cpu=8,ram_gib=16),packages=packages,source_hashes={str(f.relative_to(R)):sha(f)for f in source_files},cases_sha256=sha(P/'cases.json'),new_test_sha256=sha(R/'tests/regression/test_triple_expanded_contract.py'),vbm_diagnostic_source_hash=sha(P/'vbm-audit/VBMicrolensingLibrary.cpp'))
(P/'final-provenance.json').write_text(json.dumps(prov,indent=2))
(P/'final-status.txt').write_text(subprocess.check_output(['git','status','--short'],cwd=R,text=True))
(P/'AUDIT_STATUS.json').write_text(json.dumps(dict(state='COMPLETE_WITH_LIMITATIONS',new_fixes=2,conditions=1528,source_epochs=6520,native_engine_rows=3056,python_tests_passed=37,cpp_tests_passed=30,reference_summary='validated-reference-summary.json',remaining=['Explicit numerical refusal for extreme configurations','Unresolved VBM reference disagreements/failures','Physical gradient precision of the selected point approximation is not certified'],active_processes=0),indent=2))
allowed={'.py','.json','.log','.md','.txt','.patch','.hpp','.cpp','.h','.csv','.input'}
files=[f for f in P.rglob('*')if f.is_file()and f.suffix in allowed and f.name!='artifact-manifest.json'and '__pycache__'not in f.parts]
manifest={str(f.relative_to(P)):dict(bytes=f.stat().st_size,sha256=sha(f))for f in sorted(files)}
(P/'artifact-manifest.json').write_text(json.dumps(manifest,indent=2))
with tarfile.open(P/'validation-artifacts.tar.gz','w:gz')as archive:
 for f in sorted(files)+[P/'artifact-manifest.json']:archive.add(f,arcname=str(f.relative_to(P)),recursive=False)
(P/'validation-artifacts.sha256').write_text(sha(P/'validation-artifacts.tar.gz')+'  validation-artifacts.tar.gz\n')
print(json.dumps(dict(archive_bytes=(P/'validation-artifacts.tar.gz').stat().st_size,files=len(files),packages=packages),indent=2))
