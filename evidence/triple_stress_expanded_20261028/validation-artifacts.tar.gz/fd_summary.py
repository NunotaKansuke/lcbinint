import json
from pathlib import Path
P=Path(__file__).resolve().parent;rows=[]
for f in (P/'gradient-matrix').glob('*.json'):
 d=json.loads(f.read_text())
 for k,r in enumerate(d['rows']):
  a=r['references']['Nopoly'];b=r['references']['Multipoly'];v=a[-1]['derivative'];native=d['native'][k];noise=abs(a[-2]['derivative']-v);cross=abs(b[-1]['derivative']-v);budget=1e-3+3e-3*abs(v);rows.append(dict(case=d['case'],parameter=r['parameter'],native=native,reference=v,error=abs(native-v),budget=budget,ratio=abs(native-v)/budget,noise=noise,cross=cross,stable=noise<budget*.25,independent_agreement=cross<budget*.25))
(P/'gradient-matrix-summary.json').write_text(json.dumps(rows,indent=2));print('columns',len(rows),'stable',sum(x['stable']for x in rows),'fail stable',[(x['case'],x['parameter'],x['ratio'],x['native'],x['reference'])for x in rows if x['stable']and x['ratio']>1]);print('worst',sorted(rows,key=lambda x:x['ratio'],reverse=True)[:6])
