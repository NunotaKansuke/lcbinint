import sys,json,cmath,math
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent;R=P.parent.parent
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];sys.path.insert(0,str(R/'build-triple-native'))
import lcbinint as lc
cases=json.loads((P/'cases.json').read_text());rows=[]
for i,c in enumerate(cases[:400]):
 if i%5:continue
 p=c['params'];q=p['q'];h=p['q2'];s=p['s'];z0=q*s/(1+q);z1=-s/(1+q);z2=z0-p['sep2']*cmath.exp(1j*p['ang']);pair=(z0+h*z2)/(1+h);rot=cmath.exp(-1j*p['ang']);vel=rot*cmath.exp(1j*p['alpha']);u=vel.conjugate()*rot*(1j*p['u0']*cmath.exp(1j*p['alpha'])-pair)
 pp=dict(p,s=p['sep2'],q=h,q2=q,sep2=s,ang=-p['ang'],alpha=p['alpha']-p['ang'],t0=p['t0']-p['tE']*u.real,u0=u.imag)
 d=z2-z1;ps=dict(p,q=1/q,q2=h/q,sep2=abs(d),ang=cmath.phase(d),alpha=p['alpha']+math.pi)
 row={'case':i,'swapped_secondaries':pp,'swapped_primary':ps}
 try:
  m=lc.LightCurve(lens='triple',ld_c=c['limb'],options=lc.Options(finite_source_tol=0.,finite_source_reltol=c['rtol']));o=m.magnification(c['epochs'],p);base=np.asarray(o.magnifications);row['base']=base.tolist();row['status']=o.status.tolist()
  for name,params in [('secondary',pp),('primary',ps)]:
   v=m.magnification(c['epochs'],params);row[name]={'mu':v.magnifications.tolist(),'status':v.status.tolist(),'difference':float(np.max(abs(np.asarray(v.magnifications)/base-1)))}
 except Exception as e:row['error']=repr(e)
 rows.append(row);(P/'permutation.json').write_text(json.dumps(rows,indent=2));print(i,row.get('error',[(n,row[n]['difference'])for n in ['secondary','primary']if n in row]),flush=True)
