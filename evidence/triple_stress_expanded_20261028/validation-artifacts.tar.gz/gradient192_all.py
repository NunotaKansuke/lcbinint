import json,math,sys
from pathlib import Path
P=Path(__file__).resolve().parent
import VBMicrolensing as V
c=json.loads((P/'cases.json').read_text())[192];p=c['params'];t=c['epochs'][4];rows=[]
def value(p,method):
 v=V.VBMicrolensing();v.SetMethod(getattr(v.Method,method));v.Tol=0.;v.RelTol=1e-8;v.a1=0.;v.a2=0.;v.SetLDprofile(v.LDlinear);vp=[math.log(p[k])if k in ['s','q','rho','tE','sep2','q2']else p[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']];return float(v.TripleLightCurve(vp,[t])[0][0])
for name in ['t0','u0','tE','alpha','rho','q','s','q2','sep2','ang']:
 h=1e-3*{'t0':p['tE'],'u0':1.,'alpha':1.,'ang':1.}.get(name,abs(p[name]));r=dict(parameter=name,references={})
 for method in ['Multipoly','Nopoly']:
  a=[]
  for step in [h,h*.5,h*.25]:
   plus=value(dict(p,**{name:p[name]+step}),method);minus=value(dict(p,**{name:p[name]-step}),method);a.append(dict(h=step,plus=plus,minus=minus,derivative=(plus-minus)/(2*step)))
  r['references'][method]=a
 rows.append(r);(P/'gradient192-all-reference.json').write_text(json.dumps(rows,indent=2));print(name,[(m,r['references'][m][-1]['derivative'])for m in r['references']],flush=True)
