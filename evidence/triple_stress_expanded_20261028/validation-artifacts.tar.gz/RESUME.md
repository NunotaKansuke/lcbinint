The attached sandbox coordinator stopped with exit 143 twice. Its process namespaces were destroyed; a host-side process check found no remaining run.py or baseline worker.py processes before relaunch. Completed per-engine JSON rows were preserved and checked against input/native hashes on resume. Partial uncommitted .writing files are not accepted as completed results.

Durable resume, project directory:
```
nohup setsid env OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 /home/nunota/.miniconda3/envs/myenv/bin/python /rogue1_8/nunota/lcbinint/experiments/algebraic_boundary/evidence/triple_stress_expanded_20261028/run.py </dev/null > /rogue1_8/nunota/lcbinint/experiments/algebraic_boundary/evidence/triple_stress_expanded_20261028/detached-resume.log 2>&1 &
```
Coordinator PID 1932727, verified PPID=1, SID=1932727, five live worker children, status advanced from 4694 to 4756 tasks. PID is also in coordinator.pid. Raw outputs rows/, inputs inputs/, status status.json. Workers have one numerical thread, 2 GiB address limit, 20/22 CPU-second soft/hard limits, 45-second wall timeout. Two independent tighter-reference workers run concurrently; at most seven numerical workers plus coordinator bookkeeping. Maximum authorized resource budget: 8 CPU, 16 GiB RAM. Worker measured RSS about 34-42 MiB.
