from pathlib import Path
source=Path(__file__).with_name('chart_neighborhood.py').read_text().split('for k in range(24):')[0]
exec(compile(source,str(Path(__file__).with_name('chart_neighborhood.py')),'exec'))
rows=json.loads((P/'chart-neighborhood.json').read_text())
for r in rows:
 p=r['condition']['params'];t=r['condition']['epochs'][0]
 for name,refs in r['references'].items():
  for iteration in range(6):
   a=refs['Nopoly'];v=a[-1]['derivative'];budget=1e-3+3e-3*abs(v)
   if abs(a[-2]['derivative']-v)<budget*.1:break
   h=a[-1]['h']*.5
   for method in ['Multipoly','Nopoly']:
    plus=scalar(dict(p,**{name:p[name]+h}),t,method);minus=scalar(dict(p,**{name:p[name]-h}),t,method);refs[method].append(dict(h=h,plus=plus,minus=minus,derivative=(plus-minus)/(2*h)))
 (P/'chart-neighborhood-refined.json').write_text(json.dumps(rows,indent=2));print(r['case'],flush=True)
