import sys,json,cmath,math,time
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent;R=P.parent.parent
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];sys.path.insert(0,str(R/'build-triple-native'))
import lcbinint as lc
cases=json.loads((P/'cases.json').read_text()); results=[]
for i,c in enumerate(cases[:400]):
 if i%4:continue
 p=c['params'];q=p['q'];h=p['q2'];s=p['s'];off=q*s/(1+q);z0=complex(off);z1=complex(-s/(1+q));z2=z0-p['sep2']*cmath.exp(1j*p['ang']);com=(z0+q*z1+h*z2)/(1+q+h);b=(q*z1+h*z2)/(q+h);beta=cmath.phase(b-z0);rot=cmath.exp(-1j*beta);vel=rot*cmath.exp(1j*p['alpha']);w=rot*(1j*p['u0']*cmath.exp(1j*p['alpha'])-com);u=vel.conjugate()*w
 pn=dict(p,s=abs(b-z0),sep2=abs(z1-z2),ang=cmath.phase(rot*(z1-z2)),alpha=beta-p['alpha'],t0=p['t0']-p['tE']*u.real,u0=u.imag)
 row={'case':i,'native_params':pn}
 try:
  outputs=[]
  for typ,params in [('vbm',p),('lcbinint',pn),('center_of_mass',pn)]:
   m=lc.LightCurve(lens='triple',param_type=typ,ld_c=c['limb'],options=lc.Options(finite_source_tol=0.,finite_source_reltol=c['rtol']))
   assert m.options.param_type==typ
   o=m.magnification(c['epochs'],params);outputs.append(np.asarray(o.magnifications));row[typ]={'mu':o.magnifications.tolist(),'status':o.status.tolist()}
  row['relative_difference']=float(max(np.max(abs(x/outputs[0]-1))for x in outputs[1:]));row['ok']=row['relative_difference']<c['rtol']
 except Exception as e:row['error']=repr(e)
 results.append(row);(P/'coordinates.json').write_text(json.dumps(results,indent=2));print(i,row.get('relative_difference',row.get('error')),flush=True)
