import json,collections,math
from pathlib import Path
P=Path(__file__).resolve().parent;cases=json.loads((P/'cases.json').read_text());D=P/'rows';counts=collections.Counter();native_fail=[];disagreements=[];incomplete=0
for i,c in enumerate(cases):
 out={}
 for e in ['value','gradient','SinglePoly','MultiPoly','NoPoly']:
  f=D/(f'{i:04d}-{e}.json')
  if f.exists():out[e]=json.loads(f.read_text());counts[e+':'+out[e]['classification']]+=1
 if len(out)<5:incomplete+=1
 for e in ['value','gradient']:
  if e in out and out[e]['classification']!='ok':native_fail.append(dict(case=i,engine=e,family=c['family'],classification=out[e]['classification'],stop=out[e].get('raw_native',{}).get('stop',out[e].get('info',{}).get('stop')),error=out[e].get('error')))
 if not all(e in out and out[e]['classification']=='ok'for e in ['MultiPoly','NoPoly']):continue
 for e in ['value','gradient']:
  if e not in out or 'mu'not in out[e]:continue
  for j,(a,b,d)in enumerate(zip(out[e]['mu'],out['MultiPoly']['mu'],out['NoPoly']['mu'])):
   if a is None or b is None or d is None:continue
   error=max(abs(a/b-1),abs(a/d-1));spread=abs(b/d-1)
   if error>c['rtol']or spread>c['rtol']:
    disagreements.append(dict(case=i,engine=e,index=j,family=c['family'],error=error,spread=spread,rtol=c['rtol'],status=out[e].get('status',[None]*len(out[e]['mu']))[j],mu=a,MultiPoly=b,NoPoly=d))
r=dict(conditions=len(cases),incomplete=incomplete,counts=dict(counts),native_failures=native_fail,disagreements=disagreements)
(P/'analysis.json').write_text(json.dumps(r,indent=2));print('incomplete',incomplete,'counts',dict(counts));print('native issues',len(native_fail),'disagreements',len(disagreements));print('status0 candidates',[(x['case'],x['engine'],x['index'],round(x['error'],5),round(x['spread'],5))for x in disagreements if x['status']==0 and x['spread']<x['rtol']*.25][:20])
