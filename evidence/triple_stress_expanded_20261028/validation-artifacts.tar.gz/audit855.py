import json,subprocess,os,sys,concurrent.futures
from pathlib import Path
P=Path(__file__).resolve().parent;cs=json.loads((P/'cases.json').read_text());D=P/'audit855';D.mkdir(exist_ok=True)
def task(e,tol):
 c=dict(cs[855],rtol=tol,epochs=[-.0003,-1e-6,-1e-8,-1e-10,0.,1e-10,1e-8,1e-6,.0003]);inp=D/f'{e}-{tol}-input.json';inp.write_text(json.dumps(c))
 r=subprocess.run([sys.executable,str(P/'worker.py'),str(inp),e],capture_output=True,text=True,timeout=45,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
 try:z=json.loads(r.stdout)
 except Exception:z=dict(classification='worker_exit',returncode=r.returncode,stderr=r.stderr)
 z['rtol']=tol;(D/f'{e}-{tol}.json').write_text(json.dumps(z,indent=2));print(e,tol,z.get('mu',z.get('classification')),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(lambda x:task(*x),[(e,t)for e in ['value','gradient','MultiPoly','NoPoly']for t in ([1e-4,1e-5]if e in ['value','gradient']else[1e-7,1e-8,1e-9])]))
