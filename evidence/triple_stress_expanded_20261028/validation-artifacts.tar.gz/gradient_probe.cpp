#define LCBININT_TRIPLE_DIAGNOSTIC_TUNING 1
#include "lcbinint/magnification/algebraic_boundary/triple/integrator.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/regular_support.hpp"
#include <iostream>
#include <iomanip>
using namespace lcbinint::algebraic_boundary::triple;
int main(int argc,char**argv){
 Geometry p;std::cin>>p.X>>p.Y>>p.rho>>p.m1>>p.m2>>p.a>>p.bx>>p.by;double q,q2;std::cin>>q>>q2;
 IntegrationOptions opts;opts.absolute_tolerance=0;opts.relative_tolerance=argc>1?std::stod(argv[1]):1e-3;
 patterson_tuning.minimum_radial=argc>2?std::stoi(argv[2]):0;patterson_tuning.angular_scale=argc>3?std::stod(argv[3]):1;patterson_tuning.chart_width=argc>4?std::stod(argv[4]):0;
 opts.moving_radial_gradients=argc>5?bool(std::stoi(argv[5])):true;opts.separate_components=argc>6?bool(std::stoi(argv[6])):true;
 PreparedRegularSupport prepared;auto plan=prepared.plan(p,opts.relative_tolerance,1000000,false);if(argc>7&&std::stoi(argv[7]))plan=radial_event_plan(p);
 const auto r=integrate<true>(p,0,opts,plan.completed?&plan:nullptr);const auto d=r.normalized.df0;const double t=1+q+q2;
 std::cout<<std::setprecision(17)<<"{\"mu\":"<<r.magnification<<",\"q2\":"<<(-q*d[3]+(1+q)*d[4])/(t*t)<<",\"error\":"<<r.error_estimate<<",\"converged\":"<<r.converged<<",\"stop\":\""<<r.reason<<"\",\"nodes\":"<<r.value_evaluations<<",\"plan\":\""<<plan.reason<<"\",\"panels\":[";
 bool first=true;for(const auto& a:patterson_records){if(!first)std::cout<<',';first=false;std::cout<<"{\"lo\":"<<a.lo<<",\"hi\":"<<a.hi<<",\"level\":"<<a.level<<",\"radial_error\":"<<a.radial_error<<",\"inner_error\":"<<a.inner_error<<",\"q2_flux\":"<<(-q*a.value.df0[3]+(1+q)*a.value.df0[4])/(t*t)<<",\"cells\":[";bool cf=true;for(auto c:a.cells){if(!cf)std::cout<<',';cf=false;std::cout<<'['<<c[0]<<','<<c[1]<<','<<c[2]<<','<<c[3]<<','<<c[4]<<']';}std::cout<<"]}";}
 std::cout<<"]}\n";
}
