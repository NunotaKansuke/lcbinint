import sys,json,math,subprocess,os
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent;R=P.parent.parent
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];sys.path.insert(0,str(P/'chart-fixed-package'));import lcbinint as lc
import VBMicrolensing as V
base=json.loads((P/'cases.json').read_text())[192];rng=np.random.default_rng(1922803);out=[]
def scalar(p,t,method):
 v=V.VBMicrolensing();v.SetMethod(getattr(v.Method,method));v.Tol=0.;v.RelTol=1e-8;v.a1=0.;v.a2=0.;vp=[math.log(p[k])if k in ['s','q','rho','tE','sep2','q2']else p[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']];return float(v.TripleLightCurve(vp,[t])[0][0])
for k in range(24):
 p=dict(base['params']);p['q2']*=float(np.exp(rng.uniform(-.6,.6)));p['rho']*=float(rng.uniform(.8,1.2));p['u0']+=float(rng.uniform(-.015,.015));p['ang']+=float(rng.uniform(-.008,.008));t=base['epochs'][4];c=dict(base,params=p,epochs=[t]);m=lc.LightCurve(lens='triple',options=lc.Options(finite_source_tol=0.,finite_source_reltol=1e-3));o=m.info([t],p,with_gradient=True);r=dict(case=k,condition=c,mu=float(o.magnifications[0]),gradient=o.gradients.tolist()[0],status=o.status.tolist(),method=o.diagnostics['finite_source_method'].tolist(),references={})
 for name in ['q2','rho','u0','sep2']:
  h=1e-3*(1. if name=='u0'else abs(p[name]));refs={}
  for method in ['Multipoly','Nopoly']:
   a=[]
   for step in [h,h*.5,h*.25]:
    plus=scalar(dict(p,**{name:p[name]+step}),t,method);minus=scalar(dict(p,**{name:p[name]-step}),t,method);a.append(dict(h=step,plus=plus,minus=minus,derivative=(plus-minus)/(2*step)))
   refs[method]=a
  r['references'][name]=refs
 out.append(r);(P/'chart-neighborhood.json').write_text(json.dumps(out,indent=2));print(k,r['status'],flush=True)
