#include "VBMicrolensingLibrary.h"
#include <iostream>
#include <iomanip>
#include <cstdlib>
int main(int argc,char**argv){double p[10],t;for(auto&x:p)std::cin>>x;std::cin>>t;VBMicrolensing v;v.Tol=0;v.RelTol=std::stod(argv[1]);v.a1=std::stod(argv[2]);v.a2=0;v.maxannuli=std::stoi(argv[3]);v.SetMethod(std::stoi(argv[4])?VBMicrolensing::Method::Nopoly:VBMicrolensing::Method::Multipoly);double mu,x,y;v.TripleLightCurve(p,&t,&mu,&x,&y,1);std::cout<<std::setprecision(17)<<"{\"mu\":"<<mu<<",\"therr\":"<<v.therr<<",\"nannuli\":"<<v.nannuli<<",\"NPS\":"<<v.NPS<<",\"source\":["<<x<<','<<y<<"]}\n";}
