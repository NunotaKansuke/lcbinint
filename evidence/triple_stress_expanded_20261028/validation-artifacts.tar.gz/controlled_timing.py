import os,sys,json,time,statistics,subprocess,resource,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
if '--worker'in sys.argv:
 os.sched_setaffinity(0,{0});resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_CPU,(30,32));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
 i=int(sys.argv[2]);mode=sys.argv[3];which=sys.argv[4];sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];build=P/('api-fixed-package'if which=='before'else'chart-fixed-package');sys.path.insert(0,str(build));import lcbinint as lc
 c=json.loads((P/'cases.json').read_text())[i];c=dict(c,rtol=float(sys.argv[5]))if len(sys.argv)>5 else c;m=lc.LightCurve(lens='triple',ld_c=c['limb'],options=lc.Options(finite_source_tol=0.,finite_source_reltol=c['rtol']));ts=c['epochs'];p=c['params'];gradient=mode=='gradient';a=time.thread_time();o=m.magnification(ts,p,with_gradient=gradient);first=time.thread_time()-a
 for _ in range(2):m.magnification(ts,p,with_gradient=gradient)
 timings=[]
 for _ in range(15):
  a=time.thread_time();o=m.magnification(ts,p,with_gradient=gradient);timings.append(time.thread_time()-a)
 print(json.dumps(dict(case=i,mode=mode,version=which,first=first,warm=statistics.median(timings),samples=timings,mu=o.magnifications.tolist(),status=o.status.tolist(),gradient=o.gradients.tolist()if gradient else None,native_sha256=hashlib.sha256(Path(lc._native.__file__).read_bytes()).hexdigest())),flush=True);sys.exit()
selected=json.loads((P/'tighter-selected.json').read_text())
wait_start=time.monotonic()
while any(not(P/'tighter-reference'/f'{i:04d}-{e}.json').exists()for i in selected for e in ['MultiPoly','NoPoly']):
 if time.monotonic()-wait_start>1800:raise RuntimeError('reference completion wait limit')
 time.sleep(2)
time.sleep(2)
(P/'timing-started.json').write_text(json.dumps(dict(started=time.time(),protocol='Serial independent processes, CPU0, 2 warmups, 15 measured calls; thread CPU median excludes imports. References/builds/profiling finished; external CPU frequency/load uncontrolled.')))
D=P/'controlled-timing';D.mkdir(exist_ok=True);rows=[]
for i in [192,24,54,222,16,80,116,200]:
 for mode in ['value','gradient']:
  for which in (['before','after']if i%3 else['after','before']):
   key=f'{i:04d}-{mode}-{which}';r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',str(i),mode,which],capture_output=True,text=True,timeout=45,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
   z=json.loads(r.stdout)if r.returncode==0 else dict(error=r.stderr,returncode=r.returncode);(D/f'{key}.json').write_text(json.dumps(z,indent=2));rows.append(z);print(key,z.get('warm',z.get('error')),flush=True)
r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker','192','gradient','before','1e-4'],capture_output=True,text=True,timeout=45,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
z=json.loads(r.stdout)if r.returncode==0 else dict(error=r.stderr,returncode=r.returncode);z['rtol']=1e-4;(D/'0192-gradient-before-tight.json').write_text(json.dumps(z,indent=2));rows.append(z)
(P/'controlled-timing.json').write_text(json.dumps(rows,indent=2));(P/'timing-complete.json').write_text(json.dumps(dict(finished=time.time(),rows=len(rows))))
