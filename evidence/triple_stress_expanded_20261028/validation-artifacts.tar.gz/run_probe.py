import subprocess,json,time
from pathlib import Path
P=Path(__file__).resolve().parent;data=(P/'gradient192.input').read_text();out=[]
for label,args in [('base',['.001','0','1','0','1','1']),('tight',['.0001','0','1','0','1','1']),('min4',['.001','4','1','0','1','1']),('min5',['.001','5','1','0','1','1']),('angular_tight',['.001','0','.01','0','1','1']),('narrow',['.001','0','1','1.5','1','1']),('fixed_radial',['.001','0','1','0','0','1']),('unseparated',['.001','0','1','0','1','0']),('full_plan',['.001','0','1','0','1','1','1'])]:
 a=time.monotonic();r=subprocess.run([str(P/'gradient_probe'),*args],input=data,text=True,capture_output=True,timeout=60);raw=P/f'probe-{label}.json';raw.write_text(r.stdout)
 try:z=json.loads(r.stdout)
 except Exception:z={'error':r.stderr,'stdout':r.stdout}
 out.append(dict(label=label,args=args,wall=time.monotonic()-a,result=z));(P/'probe-results.json').write_text(json.dumps(out,indent=2));print(label,{k:v for k,v in z.items()if k!='panels'},flush=True)
