import sys,json,subprocess,os,concurrent.futures,time,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;cases=json.loads((P/'cases.json').read_text());D=P/'tighter-reference';D.mkdir(exist_ok=True);selected=[]
for i,c in enumerate(cases):
 data={}
 for e in ['value','gradient','MultiPoly','NoPoly']:
  f=P/'rows'/f'{i:04d}-{e}.json'
  if f.exists():data[e]=json.loads(f.read_text())
 if not all(e in data and 'mu'in data[e]for e in ['MultiPoly','NoPoly']):continue
 choose=False
 for e in ['value','gradient']:
  if e not in data or 'mu'not in data[e] or data[e]['classification']!='ok':continue
  for j,(a,b,d)in enumerate(zip(data[e]['mu'],data['MultiPoly']['mu'],data['NoPoly']['mu'])):
   if a is not None and b is not None and d is not None and min(b,d)>0 and max(abs(a/b-1),abs(a/d-1),abs(b/d-1))>c['rtol']*.25:choose=True
 if choose:selected.append(i)
(P/'tighter-selected.json').write_text(json.dumps(selected));print('selected',len(selected),flush=True)
def task(i,e):
 f=D/f'{i:04d}-{e}.json'
 if f.exists():
  saved=json.loads(f.read_text());assert saved['case']==i and saved['rtol']==1e-7;return
 c=dict(cases[i],rtol=1e-7);inp=D/f'{i:04d}-{e}-input.json';inp.write_text(json.dumps(c))
 try:
  r=subprocess.run([sys.executable,str(P/'worker.py'),str(inp),e],capture_output=True,text=True,timeout=45,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
  z=json.loads(r.stdout)if r.returncode==0 else dict(classification='worker_exit',returncode=r.returncode,stderr=r.stderr)
 except Exception as exc:z=dict(classification='reference_failure',error=repr(exc))
 z.update(case=i,rtol=1e-7,input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest());f.write_text(json.dumps(z,indent=2));print(i,e,z['classification'],flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=6)as pool:list(pool.map(lambda x:task(*x),[(i,e)for i in selected for e in ['MultiPoly','NoPoly']]))
