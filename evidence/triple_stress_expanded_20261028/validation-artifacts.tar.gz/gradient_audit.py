import sys,json,math,hashlib,time
from pathlib import Path
import numpy as np
P=Path(__file__).resolve().parent;R=P.parent.parent
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];sys.path.insert(0,str(R/'build-triple-native'))
import lcbinint as lc
import VBMicrolensing as V
cases=json.loads((P/'cases.json').read_text());rows=[]
def vbm(p,t,limb,method):
 v=V.VBMicrolensing();v.SetMethod(getattr(v.Method,method));v.Tol=0.;v.RelTol=1e-8;v.a1=limb;v.a2=0.;v.SetLDprofile(v.LDlinear)
 vp=[math.log(p[k])if k in ['s','q','rho','tE','sep2','q2']else p[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']];return float(v.TripleLightCurve(vp,[t])[0][0])
for i,variant in [(192,'reverse')]:
 c=cases[i];p=c['params'];ts=np.asarray(c['epochs']);m=lc.LightCurve(lens='triple',options=lc.Options(finite_source_tol=0.,finite_source_reltol=c['rtol']),ld_c=c['limb']);a=m.magnification(ts,p,with_gradient=True)
 if variant=='reverse':b=m.magnification(np.r_[ts[::-1],ts[0]],p,with_gradient=True);bg=np.asarray(b.gradients)[:-1][::-1]
 elif variant=='period':b=m.magnification(ts,dict(p,alpha=p['alpha']+2*math.pi,ang=p['ang']+2*math.pi),with_gradient=True);bg=np.asarray(b.gradients)
 else:b=m.magnification(ts+7,dict(p,t0=p['t0']+7),with_gradient=True);bg=np.asarray(b.gradients)
 ag=np.asarray(a.gradients);j,k=4,7;name=a.gradient_parameters[k];t=float(ts[j]);r={'case':i,'epoch_index':int(j),'parameter':name,'native':float(ag[j,k]),'transformed':float(bg[j,k]),'epoch':t,'reference_rtol':1e-8,'reference':{}}
 scale={'t0':p['tE'],'u0':1.,'alpha':1.,'ang':1.}.get(name,abs(p[name]));h=1e-3*max(scale,1e-8)
 for method in ['Multipoly','Nopoly']:
  estimates=[]
  for step in [h,h*.5,h*.25]:
   plus=vbm(dict(p,**{name:p[name]+step}),t,c['limb'],method);minus=vbm(dict(p,**{name:p[name]-step}),t,c['limb'],method)
   estimates.append({'h':step,'plus':plus,'minus':minus,'derivative':(plus-minus)/(2*step)})
  r['reference'][method]=estimates
 rows.append(r);(P/'gradient-audit-192.json').write_text(json.dumps(rows,indent=2));print(r,flush=True)
