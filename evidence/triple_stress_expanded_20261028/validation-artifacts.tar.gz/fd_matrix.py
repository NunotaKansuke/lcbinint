import subprocess,sys,concurrent.futures,os,json
from pathlib import Path
P=Path(__file__).resolve().parent;out=[]
def task(pair):
 try:r=subprocess.run([sys.executable,str(P/'fd_worker.py'),*map(str,pair)],capture_output=True,text=True,timeout=180,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'));return dict(case=pair[0],returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
 except Exception as e:return dict(case=pair[0],error=repr(e))
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for r in pool.map(task,[(24,1),(54,0),(222,0),(16,5),(118,1),(370,1),(80,0),(116,0),(200,0)]):
  out.append(r);(P/'gradient-matrix-status.json').write_text(json.dumps(out,indent=2));print(r,flush=True)
