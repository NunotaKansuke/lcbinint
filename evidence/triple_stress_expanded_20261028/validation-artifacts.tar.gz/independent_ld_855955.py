import sys,json,math,resource
from pathlib import Path
import numpy as np
import VBMicrolensing as V
P=Path(__file__).resolve().parent;resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(60,65))
cs=json.loads((P/'cases.json').read_text());out=[]
for i in [855,955]:
 c=cs[i];p=c['params'];vp=[math.log(p[k])if k in ['s','q','rho','tE','sep2','q2']else p[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']]
 for method in ['Multipoly','Nopoly']:
  v=V.VBMicrolensing();v.SetMethod(getattr(v.Method,method));v.Tol=0.;v.RelTol=1e-8;v.a1=0.;v.a2=0.;z=v.TripleLightCurve(vp,[0.]);uniform=float(z[0][0]);x=float(z[1][0]);y=float(z[2][0])
  for n in [16,32,64,128]:
   a,w=np.polynomial.legendre.leggauss(n);theta=(a+1)*math.pi/4;weights=w*math.pi/4;rad=p['rho']*np.sin(theta);mu=[float(v.MultiMag(x,y,float(r)))for r in rad];integral=float(np.dot(weights,np.sin(theta)**3*np.asarray(mu)));ld=((1-c['limb'])*uniform+c['limb']*integral)/(1-c['limb']/3);row=dict(case=i,method=method,n=n,uniform=uniform,source=[x,y],rho=p['rho'],limb=c['limb'],reference_rtol=1e-8,theta=theta.tolist(),weights=weights.tolist(),radii=rad.tolist(),uniform_mu=mu,mu=ld);out.append(row);(P/'independent-ld.json').write_text(json.dumps(out,indent=2));print(i,method,n,ld,flush=True)
