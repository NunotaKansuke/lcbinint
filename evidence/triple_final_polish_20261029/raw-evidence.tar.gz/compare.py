import json,collections,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;Q=P.parent/'triple_contact_precision_20261029'
cases=json.loads((P/'cases.json').read_text());counts={};changes=[];recovered=set();regressions=[];changed=[]
for e in ['value','gradient']:
 counts[e]=collections.Counter()
 for i,c in enumerate(cases):
  name=f'{i:04d}-{e}.json';a=json.loads((P/'rows'/name).read_text());b=json.loads((Q/'rows'/name).read_text());counts[e][a['classification']]+=1
  if a['classification']!=b['classification']:
   row=dict(case=i,engine=e,before=b['classification'],after=a['classification']);changes.append(row)
   if a['classification']=='ok':recovered.add(i)
   if b['classification']=='ok':regressions.append(row)
  if 'mu'in a and 'mu'in b:
   delta=max([abs(x/y-1)for x,y in zip(a['mu'],b['mu'])if x and y]or[0])
   if delta>c['rtol']*.1:changed.append(dict(case=i,engine=e,relative_change=delta,requested=c['rtol']))
summary=dict(counts={k:dict(v)for k,v in counts.items()},changes=changes,recovered_conditions=sorted(recovered),regressions=regressions,changed=changed)
(P/'comparison.json').write_text(json.dumps(summary,indent=2));print({k:v for k,v in summary.items()if k not in ['changes','changed','recovered_conditions']});print('recovered',len(recovered),'changed',len(changed))
