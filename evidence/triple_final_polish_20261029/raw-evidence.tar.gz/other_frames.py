import json,subprocess,resource,time,concurrent.futures
from pathlib import Path
P=Path(__file__).resolve().parent;D=P/'other-frames';D.mkdir(exist_ok=True)
def limits():
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_CPU,(12,14));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
def run(task):
 i,b,o=task;c=json.loads((P/'inputs'/f'{i:04d}.json').read_text());p=c['params'];v=[p[k]for k in ['t0','u0','tE','alpha','s','q','q2','sep2','ang','rho']]+[c['limb'],c['rtol'],1,c['epochs'][len(c['epochs'])//2]];start=time.time()
 try:
  r=subprocess.run([str(P/b),str(o)],input=' '.join(map(str,v)),text=True,capture_output=True,timeout=22,preexec_fn=limits);z=dict(case=i,binary=b,origin=o,code=r.returncode,stdout=r.stdout,stderr=r.stderr,elapsed=time.time()-start)
 except Exception as e:z=dict(case=i,binary=b,origin=o,error=repr(e))
 (D/f'{i}-{b}-{o}.json').write_text(json.dumps(z,indent=2));print(i,b,o,z.get('code'),z.get('stdout',''),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as ex:list(ex.map(run,[(i,'probe-all-frames',o)for i in [5,52,135,189,226,314,337,361,400,484]for o in [3,4,5]]))
