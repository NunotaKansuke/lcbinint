import sys,json,time
from pathlib import Path
P=Path(__file__).resolve().parent
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];sys.path.insert(0,str(P/'reuse-package'))
import lcbinint as lc
c=json.loads((P/'cases.json').read_text())[972];p=c['params'];m=lc.LightCurve(lens='triple',ld_c=c['limb'],options=lc.Options(finite_source_tol=0.,finite_source_reltol=c['rtol']));rows=[]
for h in [2e-7,1e-7,5e-8,2e-8,1e-8,5e-9,2.5e-9]:
 z=dict(h=h)
 try:
  plus=m.magnification([0.],dict(p,t0=p['t0']+h)).magnifications[0];minus=m.magnification([0.],dict(p,t0=p['t0']-h)).magnifications[0];z.update(plus=float(plus),minus=float(minus),derivative=float((plus-minus)/(2*h)))
 except Exception as exc:z['error']=repr(exc)
 rows.append(z);(P/'native-reframed-fd.json').write_text(json.dumps(rows,indent=2));print(z,flush=True)
