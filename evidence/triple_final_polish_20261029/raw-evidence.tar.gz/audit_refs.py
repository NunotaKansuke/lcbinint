import os,sys,json,math,subprocess,resource,concurrent.futures,time,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent;Q=P.parent/'triple_contact_precision_20261029';E=P.parent/'triple_stress_expanded_20261028';cases=json.loads((P/'cases.json').read_text());old=json.loads((Q/'validated-reference-comparisons.json').read_text());selected={(r['case'],r['index'])for r in old if cases[r['case']]['limb']>0}
for i in json.loads((P/'selected-contact.json').read_text()):
 if cases[i]['limb']>0:selected.update((i,j)for j in range(len(cases[i]['epochs'])))
D=P/'ld-cap-audit';D.mkdir(exist_ok=True);probe=E/'vbm-audit/probe';(P/'ld-cap-audit-provenance.json').write_text(json.dumps(dict(probe=str(probe.resolve()),sha256=hashlib.sha256(probe.read_bytes()).hexdigest(),points=len(selected),methods=['Multipoly','Nopoly'],tolerance=1e-7,cap=100),indent=2))
def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(20,22));resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.sched_setaffinity(0,{1,2,3})
def task(job):
 i,j,e=job;f=D/f'{i:04d}-{j}-{e}.json'
 if f.exists():return json.loads(f.read_text())
 c=cases[i];p=c['params'];vp=[math.log(p[k])if k in ['s','q','rho','tE','sep2','q2']else p[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']];data=' '.join(map(repr,vp+[c['epochs'][j]]))+'\n';z=dict(case=i,index=j,method=e,rtol=1e-7,cap=100,input_sha256=hashlib.sha256(data.encode()).hexdigest())
 try:
  r=subprocess.run([str(probe),'1e-7',str(c['limb']),'100',str(e)],input=data,text=True,capture_output=True,timeout=45,preexec_fn=limits)
  if r.returncode==0:
   z['result']=json.loads(r.stdout);v=z['result'];z['cap_exhausted']=v['nannuli']>=100 and v['therr']>1e-7*abs(v['mu'])
  else:z.update(returncode=r.returncode,stderr=r.stderr[-2000:])
 except Exception as exc:z['error']=repr(exc)
 f.write_text(json.dumps(z,indent=2));return z
jobs=[(i,j,e)for i,j in sorted(selected)for e in [0,1]];done=0;caps=0;fail=0;start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=3)as pool:
 for z in pool.map(task,jobs):
  done+=1;caps+=bool(z.get('cap_exhausted'));fail+='result'not in z
  if done%20==0:
   state=dict(state='RUNNING',pid=os.getpid(),completed=done,total=len(jobs),cap_exhausted=caps,failures=fail,elapsed=time.time()-start,updated=time.time());(P/'ld-cap-audit-status.json').write_text(json.dumps(state,indent=2));print(done,caps,fail,flush=True)
state.update(state='COMPLETE',completed=done,cap_exhausted=caps,failures=fail,elapsed=time.time()-start);(P/'ld-cap-audit-status.json').write_text(json.dumps(state,indent=2));print(state,flush=True)
