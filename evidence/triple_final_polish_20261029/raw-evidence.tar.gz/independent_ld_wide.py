import sys,os,json,math,resource,subprocess,concurrent.futures,time
from pathlib import Path
P=Path(__file__).resolve().parent;D=P/'ld-independent-wide';D.mkdir(exist_ok=True)
if '--worker'in sys.argv:
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(60,62));os.sched_setaffinity(0,{4,5,6,7})
 import numpy as np,VBMicrolensing as V
 i,j,e=int(sys.argv[2]),int(sys.argv[3]),sys.argv[4];c=json.loads((P/'cases.json').read_text())[i];p=c['params'];f=D/f'{i:04d}-{j}-{e}.json';out=dict(case=i,index=j,method=e,reference_rtol=1e-6,rows=[])
 if f.exists():out=json.loads(f.read_text())
 if out.get('converged'):sys.exit()
 v=V.VBMicrolensing();v.SetMethod(getattr(v.Method,e));v.Tol=0.;v.RelTol=1e-6;v.a1=0.;v.a2=0.;vp=[math.log(p[k])if k in ['s','q','rho','tE','sep2','q2']else p[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']];o=v.TripleLightCurve(vp,[c['epochs'][j]]);uniform=float(o[0][0]);x,y=float(o[1][0]),float(o[2][0]);out.update(uniform=uniform,source=[x,y])
 for n in [16,32,64,128,256]:
  if any(r['n']==n for r in out['rows']):continue
  start=time.thread_time();a,w=np.polynomial.legendre.leggauss(n);theta=(a+1)*math.pi/4;weight=w*math.pi/4;rad=p['rho']*np.sin(theta);vals=[float(v.MultiMag(x,y,float(r)))for r in rad];mu=((1-c['limb'])*uniform+c['limb']*float(np.dot(weight,np.sin(theta)**3*np.asarray(vals))))/(1-c['limb']/3);out['rows'].append(dict(n=n,mu=mu,radii=rad.tolist(),uniform_mu=vals,cpu_seconds=time.thread_time()-start))
  if len(out['rows'])>=3:
   last=[r['mu']for r in out['rows'][-3:]];out['change']=max(abs(last[2]-last[1]),abs(last[1]-last[0]));out['converged']=out['change']<=c['rtol']*.02*abs(mu)
  f.write_text(json.dumps(out,indent=2))
  if out.get('converged'):break
 sys.exit()
selected=json.loads((P/('ld-independent-wide-selected.json')).read_text());start=time.time();done=0
jobs=[(i,j,e)for i,j in selected for e in ['Multipoly','Nopoly']]
def task(job):
 i,j,e=job
 try:
  r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',str(i),str(j),e],capture_output=True,text=True,timeout=125,env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'));z=dict(case=i,index=j,method=e,returncode=r.returncode,stderr=r.stderr[-2000:])
 except Exception as exc:z=dict(case=i,index=j,method=e,error=repr(exc))
 (D/f'{i:04d}-{j}-{e}-status.json').write_text(json.dumps(z));return z
with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
 for z in pool.map(task,jobs):
  done+=1;(P/'ld-independent-wide-status.json').write_text(json.dumps(dict(state='RUNNING',pid=os.getpid(),completed=done,total=len(jobs),elapsed=time.time()-start,updated=time.time()),indent=2));print(done,z['case'],z['index'],z['method'],z.get('returncode',z.get('error')),flush=True)
(P/'ld-independent-wide-status.json').write_text(json.dumps(dict(state='COMPLETE',completed=done,total=len(jobs),elapsed=time.time()-start),indent=2))
