#include <cstdio>
static unsigned trace_count=0;
#define TRACE_FAIL(...) do{if(trace_count++<2000)std::fprintf(stderr,__VA_ARGS__);}while(0)
#define LCBININT_TRIPLE_DIAGNOSTIC_TUNING 1
#define LCBININT_TRIPLE_COUPLED_PROFILE 1
#include "lcbinint/magnification/algebraic_boundary/triple/integrator.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/regular_support.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/frame.hpp"
#include "lcbinint/model/triple_lens_geometry.hpp"
#include <iostream>
#include <iomanip>
using namespace lcbinint;namespace tr=algebraic_boundary::triple;
int main(int argc,char**argv){bool grad=argc<2||std::atoi(argv[1]);double t0,u0,tE,alpha,s,q,q2,sep,ang,rho,limb,tol;int n;std::cin>>t0>>u0>>tE>>alpha>>s>>q>>q2>>sep>>ang>>rho>>limb>>tol>>n;
 auto geo=model::make_triple_lens_geometry_vbm(s,q,sep,ang,q2);std::array<tr::Complex,3> lens;for(int k=0;k<3;++k)lens[k]={geo.lens_positions[k].x,geo.lens_positions[k].y};tr::PreparedRegularSupport prep;tr::IntegrationOptions opt;opt.absolute_tolerance=0;opt.relative_tolerance=tol;
 for(int k=0;k<n;++k){double t;std::cin>>t;double tau=(t-t0)/tE;tr::Complex source(tau*std::cos(alpha)-u0*std::sin(alpha),tau*std::sin(alpha)+u0*std::cos(alpha));auto frame=tr::primary_frame<true>(lens,source,rho,geo.masses[1],geo.masses[2]);auto p=frame.geometry;auto plan=prep.plan(p,tol,1000000,false);tr::patterson_records.clear();tr::coupled_profile::exclusive.fill(0);tr::coupled_profile::nanoseconds.fill(0);tr::coupled_profile::calls.fill(0);const double start=tr::coupled_profile::cpu_time();const auto r=tr::integrate<PROFILE_GRAD>(p,limb,opt,plan.completed?&plan:nullptr);const double total=tr::coupled_profile::cpu_time()-start;std::cerr<<"PROFILE total_ns "<<total<<" exclusive";for(auto t:tr::coupled_profile::exclusive)std::cerr<<" "<<t;std::cerr<<" calls";for(auto t:tr::coupled_profile::calls)std::cerr<<" "<<t;std::cerr<<"\n";
 std::cout<<std::setprecision(17)<<"{\"index\":"<<k<<",\"mu\":"<<(std::isfinite(r.magnification)?std::to_string(r.magnification):"null")<<",\"stop\":\""<<r.reason<<"\",\"valid\":"<<r.gradient_valid<<",\"nodes\":"<<r.value_evaluations<<",\"events\":"<<r.support.events.size()<<"}\n";
 }
}
