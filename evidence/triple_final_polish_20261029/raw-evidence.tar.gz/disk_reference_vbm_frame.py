"""Independent validation only: source-disk average of VBM point values."""
import os,sys,json,math,resource,subprocess,concurrent.futures,time
from pathlib import Path
P=Path(__file__).resolve().parent;D=P/'point-disk-vbm-frame';D.mkdir(exist_ok=True)
if '--worker'in sys.argv:
 resource.setrlimit(resource.RLIMIT_CORE,(0,0));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CPU,(30,32));os.sched_setaffinity(0,{1,2})
 import numpy as np,VBMicrolensing as V
 i,j,e=int(sys.argv[2]),int(sys.argv[3]),sys.argv[4];c=json.loads((P/'cases.json').read_text())[i];p=c['params'];v=V.VBMicrolensing();v.SetMethod(getattr(v.Method,e));v.Tol=0.;v.RelTol=1e-9;v.a1=0.;v.a2=0.
 vp=[math.log(p[k])if k in ['s','q','rho','tE','sep2','q2']else p[k]for k in ['s','q','u0','alpha','rho','tE','t0','sep2','q2','ang']];o=v.TripleLightCurve(vp,[c['epochs'][j]]);x,y=float(o[1][0]),float(o[2][0]);off=p['q']*p['s']/(1+p['q']);lens=[complex(off,0),complex(-p['s']/(1+p['q']),0),complex(off,0)-p['sep2']*complex(math.cos(p['ang']),math.sin(p['ang']))];total=1+p['q']+p['q2'];mass=[1/total,p['q']/total,p['q2']/total];v.SetLensGeometry([a for z,m in zip(lens,mass)for a in [-z.real,-z.imag,m]])
 f=D/f'{i:04d}-{j}-{e}.json';out=dict(case=i,index=j,method=e,source=[x,y],rows=[],formula='integral 2*u*(1-c+c*u)*mean_theta(MultiMag0(source+rho*sqrt(1-u*u)*exp(i theta))) du / (1-c/3)')
 for n in [4,8,16]:
  a,w=np.polynomial.legendre.leggauss(n);u=(a+1)/2;weights=w/2;values=[];averages=[];start=time.thread_time()
  for uu in u:
   r=p['rho']*math.sqrt(1-uu*uu);row=[float(v.MultiMag0(x+r*math.cos(2*math.pi*k/(4*n)),y+r*math.sin(2*math.pi*k/(4*n))))for k in range(4*n)];values.append(row);averages.append(sum(row)/(4*n))
  mu=float(sum(ww*2*uu*(1-c['limb']+c['limb']*uu)*av for ww,uu,av in zip(weights,u,averages))/(1-c['limb']/3));out['rows'].append(dict(n=n,mu=mu,point_values=values,cpu_seconds=time.thread_time()-start));f.write_text(json.dumps(out))
 sys.exit()
def task(job):
 i,j,e=job
 try:
  r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',str(i),str(j),e],text=True,capture_output=True,timeout=65);z=dict(case=i,index=j,method=e,returncode=r.returncode,stderr=r.stderr[-1000:])
 except Exception as exc:z=dict(case=i,index=j,method=e,error=repr(exc))
 (D/f'{i:04d}-{j}-{e}-status.json').write_text(json.dumps(z));print(i,j,e,z.get('returncode',z.get('error')),flush=True)
cs=json.loads((P/'cases.json').read_text());jobs=[(i,j,e)for i in [135,189,314,337,361,431]for j in range(len(cs[i]['epochs']))for e in ['Multipoly','Nopoly']]
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:list(pool.map(task,jobs))
(P/'point-disk-vbm-frame-complete.json').write_text(json.dumps(dict(jobs=len(jobs),finished=time.time())))
