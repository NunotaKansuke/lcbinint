import json,sys,subprocess,concurrent.futures,os,time
from pathlib import Path
P=Path(__file__).resolve().parent;D=P/'recovered-tight';D.mkdir(exist_ok=True)
if '--worker'in sys.argv:
 import worker
 worker.os.sched_setaffinity(0,{1,2,3});worker.resource.setrlimit(worker.resource.RLIMIT_CPU,(20,22))
 i=int(sys.argv[2]);c=json.loads((P/'cases.json').read_text())[i];c['rtol']=1e-7
 print(json.dumps(worker.run(c,sys.argv[3]),allow_nan=False),flush=True);sys.exit()
def task(job):
 i,e=job
 try:
  r=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--worker',str(i),e],capture_output=True,text=True,timeout=45);z=json.loads(r.stdout)if r.returncode==0 else dict(returncode=r.returncode,stderr=r.stderr[-1000:])
 except Exception as exc:z=dict(error=repr(exc))
 (D/f'{i:04d}-{e}.json').write_text(json.dumps(z,indent=2));return i,e
ids=json.loads((P/'comparison.json').read_text())['recovered_conditions'];start=time.time()
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for n,r in enumerate(pool.map(task,[(i,e)for i in ids for e in ['MultiPoly','NoPoly']]),1):
  print(n,*r,flush=True);(P/'recovered-tight-status.json').write_text(json.dumps(dict(state='RUNNING',pid=os.getpid(),done=n,total=len(ids)*2,elapsed=time.time()-start)))
(P/'recovered-tight-status.json').write_text(json.dumps(dict(state='COMPLETE',done=len(ids)*2,total=len(ids)*2,elapsed=time.time()-start)))
