#include <cstdio>
static unsigned trace_count=0;
#define TRACE_FAIL(...) do{if(trace_count++<2000)std::fprintf(stderr,__VA_ARGS__);}while(0)
#define LCBININT_TRIPLE_DIAGNOSTIC_TUNING 1
#include "lcbinint/magnification/algebraic_boundary/triple/integrator.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/regular_support.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/frame.hpp"
#include "lcbinint/model/triple_lens_geometry.hpp"
#include <iostream>
#include <iomanip>
using namespace lcbinint;namespace tr=algebraic_boundary::triple;
int main(int argc,char**argv){int origin=argc>1?std::atoi(argv[1]):0;double t0,u0,tE,alpha,s,q,q2,sep,ang,rho,limb,tol;int n;std::cin>>t0>>u0>>tE>>alpha>>s>>q>>q2>>sep>>ang>>rho>>limb>>tol>>n;
 auto geo=model::make_triple_lens_geometry_vbm(s,q,sep,ang,q2);std::array<tr::Complex,3> lens;for(int k=0;k<3;++k)lens[k]={geo.lens_positions[k].x,geo.lens_positions[k].y};tr::PreparedRegularSupport prep;tr::IntegrationOptions opt;opt.absolute_tolerance=0;opt.relative_tolerance=tol;
 for(int k=0;k<n;++k){double t;std::cin>>t;double tau=(t-t0)/tE;tr::Complex source(tau*std::cos(alpha)-u0*std::sin(alpha),tau*std::sin(alpha)+u0*std::cos(alpha));std::array<int,3> perm=origin==1?std::array<int,3>{1,0,2}:origin==2?std::array<int,3>{2,0,1}:std::array<int,3>{0,1,2};if(geo.masses[perm[1]]<geo.masses[perm[2]])std::swap(perm[1],perm[2]);std::array<tr::Complex,3> ordered{lens[perm[0]],lens[perm[1]],lens[perm[2]]};auto frame=tr::primary_frame<true>(ordered,source,rho,geo.masses[perm[1]],geo.masses[perm[2]]);auto p=frame.geometry;std::fprintf(stderr,"MASS_ROUNDOFF origin=%d mass=%.17g error=%.17g\n",origin,p.masses()[0],p.masses()[0]-double(__float128(1)-__float128(p.m1)-__float128(p.m2)));auto plan=prep.plan(p,tol,1000000,false);tr::patterson_records.clear();const auto r=tr::integrate<true>(p,limb,opt,plan.completed?&plan:nullptr);
 auto g=frame.pullback(r.normalized.df0);std::array<double,11> og{};og[0]=g[0];og[1]=g[1];og[2]=g[2];std::array<double,3> mg{};mg[perm[1]]=g[3];mg[perm[2]]=g[4];og[3]=mg[1]-mg[0];og[4]=mg[2]-mg[0];for(int j=0;j<3;++j){og[5+2*perm[j]]=g[5+2*j];og[6+2*perm[j]]=g[6+2*j];}auto pg=tr::lens_parameter_pullback(og,s,q,q2,sep,ang,true);std::fprintf(stderr,"PARAM_GRAD q2=%.17g rho=%.17g\n",pg[2],og[2]);std::cout<<std::setprecision(17)<<"{\"index\":"<<k<<",\"mu\":"<<(std::isfinite(r.magnification)?std::to_string(r.magnification):"null")<<",\"stop\":\""<<r.reason<<"\",\"valid\":"<<r.gradient_valid<<",\"nodes\":"<<r.value_evaluations<<",\"events\":"<<r.support.events.size()<<"}\n";
 }
}
