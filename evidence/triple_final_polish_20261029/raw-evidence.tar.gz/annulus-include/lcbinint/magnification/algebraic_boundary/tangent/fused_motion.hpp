#pragma once
#include <array>
#include <algorithm>
#include <cmath>
#include <limits>
namespace lcbinint::algebraic_boundary::tangent::fused_gradient {
inline bool com_tangent_frame(double separation,double source_radius) {
    return source_radius<std::sqrt(std::sqrt(std::numeric_limits<double>::epsilon()))*
        std::max(1.,separation);
}
// Scoped per-node scheduling: only value-adaptive child panels postpone
// tangents until their final geometry has been accepted.
inline thread_local bool defer_sample_tangents=false;
inline thread_local bool reliability_retry_used=false;
inline thread_local bool precise_tangent_replay=false;
inline thread_local bool com_tangent_replay=false;
struct ComTangentScope {
    bool previous;
    explicit ComTangentScope(bool enabled):previous(com_tangent_replay){com_tangent_replay=enabled;}
    ~ComTangentScope(){com_tangent_replay=previous;}
};
struct PreciseTangentScope {
    bool previous;
    explicit PreciseTangentScope(bool enabled=true):previous(precise_tangent_replay){precise_tangent_replay=previous||enabled;}
    ~PreciseTangentScope(){precise_tangent_replay=previous;}
};
struct TangentScheduleScope {
    bool previous;
    explicit TangentScheduleScope(bool defer):previous(defer_sample_tangents){defer_sample_tangents=defer;}
    ~TangentScheduleScope(){defer_sample_tangents=previous;}
};
struct Motion { std::array<double,5> radius{}, jacobian{}; };
inline thread_local const Motion* active_motion=nullptr;
inline thread_local double radius_offset=0;
struct RadiusOffsetScope {
 double previous;
 explicit RadiusOffsetScope(double offset):previous(radius_offset){radius_offset=offset;}
 ~RadiusOffsetScope(){radius_offset=previous;}
};
struct MotionScope {
    const Motion* previous;
    explicit MotionScope(const Motion* motion):previous(active_motion){active_motion=motion;}
    ~MotionScope(){active_motion=previous;}
};
}
