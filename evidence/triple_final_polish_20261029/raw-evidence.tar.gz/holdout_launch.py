import os,json,time,sys
from pathlib import Path
P=Path(__file__).resolve().parent
(P/'holdout-launch-state.json').write_text(json.dumps(dict(state='WAITING_FOR_SERIAL_TIMING',pid=os.getpid(),started=time.time())))
while not(P/'final-timing-complete.json').exists():time.sleep(1)
(P/'holdout-launch-state.json').write_text(json.dumps(dict(state='EXEC_HOLDOUT',pid=os.getpid(),started=time.time())))
os.execv(sys.executable,[sys.executable,str(P/'holdout_run.py')])
