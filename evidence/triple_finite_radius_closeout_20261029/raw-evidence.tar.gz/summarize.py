import json,hashlib,collections
from pathlib import Path
D=Path(__file__).resolve().parent;P=D.parent/'triple_local_chart_followup_20261029'
identity=hashlib.sha256((D/'package/lcbinint/_lcbinint.cpython-310-x86_64-linux-gnu.so').read_bytes()).hexdigest()
s=json.loads((P/'finite-radius-v2-status.json').read_text());assert s['total']==s['completed']==3712 and s['state'].startswith('COMPLETE') and s['native_sha256']==identity
native={};counts=collections.Counter();regressions=[];changes=[]
for f in sorted((P/'finite-radius-v2-rows').glob('*.json')):
 r=json.loads(f.read_text());assert r['native_sha256']==identity
 old=json.loads((P/'accepted-rows'/f.name).read_text());assert r['input_sha256']==old['input_sha256']
 i=r['case']+dict(main=0,followup=1768,holdout=1800)[r['group']];native[i,r['engine']]=r;counts[r['engine']+':'+r['classification']]+=1
 if old['classification']=='ok' and r['classification']!='ok':regressions.append(f.name)
 if old['classification']!=r['classification']:changes.append(f.name)
comparisons=[]
for q in json.loads((P/'qualified-comparisons.json').read_text()):
 r=native[q['case'],q['engine']]
 if r['classification']!='ok':continue
 c=json.loads(((D.parent/'triple_event_precision_20261029/inputs' if q['case']<1768 else D.parent/'triple_event_precision_20261029/followup/inputs' if q['case']<1800 else P/'holdout/inputs')/f"{q['case'] if q['case']<1768 else q['case']-1768 if q['case']<1800 else q['case']-1800:04d}.json").read_text())
 error=max(abs(r['mu'][q['index']]/v-1) for v in q['reference_values'])/c['rtol']
 comparisons.append(dict(case=q['case'],index=q['index'],engine=q['engine'],error_over_requested=error))
(D/'qualified-comparisons.json').write_text(json.dumps(comparisons,indent=2))
grad=json.loads((D/'gradient-comparison.json').read_text());assert grad['native_sha256']==identity
inv=json.loads((D/'invariants.json').read_text());assert len(inv)==167
checks=[v for r in inv for v in r.get('checks',{}).values()]
out=dict(native_sha256=identity,conditions=1856,counts=counts,classification_regressions=regressions,classification_changes=changes,value_comparisons=len(comparisons),maximum_error_over_requested=max(r['error_over_requested'] for r in comparisons),value_exceedances=[r for r in comparisons if r['error_over_requested']>1],independent_gradient_checks=sum(len(r['rows']) for r in grad['rows']),maximum_scaled_gradient_error=max(x['scaled_error'] for r in grad['rows'] for x in r['rows']),invariant_curves=len(inv),invariant_checks=len(checks),invariant_errors=[r for r in inv if 'error' in r],invariant_exceedances=[r for r in checks if r['value_relative']>1e-4 or r['gradient_scaled']>1e-4],max_invariant_gradient=max(r['gradient_scaled'] for r in checks))
(D/'SUMMARY.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
