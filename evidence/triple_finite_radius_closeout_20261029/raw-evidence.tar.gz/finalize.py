import sys,json,hashlib,subprocess,platform,socket,shutil
from pathlib import Path
D=Path(__file__).resolve().parent;P=D.parent/'triple_local_chart_followup_20261029';R=Path.cwd();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((P/'PROVENANCE.json').read_text());files=old['source_hashes'];sources={p:sha(p)for p in files}
for p in files:
 dst=D/'source-snapshot'/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
wrappers={}
for p in (D/'package').rglob('*.py'):
 rel=p.relative_to(D/'package');wrappers[str(rel)]=sha(p);dst=D/'wrapper-snapshot'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
tests=['tests/triple_algebraic/test_local_images.cpp','tests/regression/test_triple_caustic_progress.py','tests/regression/test_triple_default_pipeline.py','tests/regression/test_triple_local_images.py']
for p in tests:
 dst=D/'test-snapshot'/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
for tag in ['finite-radius','finite-radius-v2']:
 shutil.copytree(P/(tag+'-rows'),D/'raw'/(tag+'-rows'),dirs_exist_ok=True);shutil.copy2(P/(tag+'-status.json'),D/'raw'/(tag+'-status.json'))
identity=sha(D/'package/lcbinint/_lcbinint.cpython-310-x86_64-linux-gnu.so');assert identity==sha('build-triple-native/_lcbinint.cpython-310-x86_64-linux-gnu.so')=='021f6216986b54fbeea6d1bdd107c8ff8fa261c27e0c7b440cf23ab35b662863'
prov=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(),host=socket.gethostname(),platform=platform.platform(),python=sys.version,native_sha256=identity,baseline_native_sha256=old['native_sha256'],attempt1_native_sha256=sha(D/'attempt1-package/_lcbinint.cpython-310-x86_64-linux-gnu.so'),project_source_hashes=sources,changed_project_sources=[p for p,h in sources.items()if h!=files[p]],wrapper_hashes=wrappers,test_hashes={p:sha(p)for p in tests},environment_from_previous=old['python'],compiler=old['compiler'],vbm_native=old['vbm_native'],vbm_native_sha256=sha(old['vbm_native']),vbm_references='Reused qualified-comparisons and raw Single/Multi/NoPoly from triple_local_chart_followup_20261029. No fresh VBM timing run.',resource_budget=dict(cpu_max=8,ram_gib=16,native_workers=4,threads_per_library=1,native_worker_address_space_gib=2),build_flags={p.parent.name:p.read_text()for p in [Path('build-triple-native/CMakeFiles/lcbinint_magnification.dir/flags.make'),Path('build-triple-native/CMakeFiles/lcbinint_python.dir/flags.make')]},claim_limits=['Two original curve failures remain: main439/main499.','LD integration bottleneck unchanged.','All70 independent finite-source gradients checked only at seven fixed centers.','Exact warm timings do not certify fit throughput.'])
assert prov['changed_project_sources']==['src/lcbinint/magnification/finite_source_magnifier.cpp','src/lcbinint/magnification/point_source_magnifier.cpp']
(D/'PROVENANCE.json').write_text(json.dumps(prov,indent=2)+'\n');(D/'source.patch').write_bytes(subprocess.check_output(['git','diff','--',*prov['changed_project_sources'],*tests]));print(identity,len(sources),len(wrappers))
