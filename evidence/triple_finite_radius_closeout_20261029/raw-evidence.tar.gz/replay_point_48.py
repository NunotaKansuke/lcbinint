import sys,json,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable' not in str(f)];sys.path.insert(0,str(Path(sys.argv[1]).resolve()))
import lcbinint as lc
c=json.loads((D.parent/'triple_local_chart_followup_20261029/holdout/inputs/0048.json').read_text());p=c['params'];m=lc.LightCurve(lens='triple',param_type='vbm',options=lc.Options(finite_source_tol=0.,finite_source_reltol=c['rtol']))
rows=[]
for a in json.loads((D/'point-reference-48.json').read_text()):
 v=dict(p,t0=-a['x'],u0=a['y'],alpha=0.,rho=0.)
 o=m.info([0.],v,with_gradient=True)
 rows.append(dict(x=a['x'],y=a['y'],mu=o.magnifications.tolist(),reference=a['mu'],status=o.status.tolist()))
print(json.dumps(dict(native_sha256=hashlib.sha256(Path(lc._native.__file__).read_bytes()).hexdigest(),rows=rows),indent=2))
