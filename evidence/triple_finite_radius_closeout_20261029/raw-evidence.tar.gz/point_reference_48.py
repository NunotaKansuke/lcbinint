import sys,json,math
from pathlib import Path
D=Path(__file__).resolve().parent;P=D.parent/'triple_local_chart_followup_20261029'
sys.argv=[str(P/'mp_holdout.py'),'48']
s=(P/'mp_holdout.py').read_text().split('def disk(')[0]
ns={'__file__':str(P/'mp_holdout.py'),'__name__':'reference'};exec(compile(s,str(P/'mp_holdout.py'),'exec'),ns)
mp=ns['mp'];Q=mp.mpf;C=mp.mpc;x=.002901204496815435;y=.005880087290325666;r=.00010893355442672599;h=.7071067811865475244
axes=[(1,0),(0,1),(-1,0),(0,-1)];diags=[(h,h),(-h,h),(-h,-h),(h,-h)];points=[(x,y)]
for a,b in zip(axes,diags):
 for direction,scale in [(a,1),(a,.5),(b,1)]:points.append((x+r*scale*direction[0],y+r*scale*direction[1]))
rows=[]
for x,y in points:
 w=C(x,y);roots=ns['roots_at'](w);assert len(roots)==4
 det=[1-abs(ns['field'](z,w)[1])**2 for z in roots];assert sum(d>0 for d in det)==1
 residual=max(abs(ns['field'](z,w)[0]) for z in roots);assert residual<Q('1e-52')
 rows.append(dict(x=x,y=y,mu=str(sum(1/abs(d) for d in det)),residual=str(residual)))
(D/'point-reference-48.json').write_text(json.dumps(rows,indent=2));print(rows,flush=True)
