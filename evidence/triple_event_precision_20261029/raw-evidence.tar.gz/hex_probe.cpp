#include "lcbinint/magnification/triple_approximation.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/regular_support.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/frame.hpp"
#include <iostream>
#include <iomanip>
using namespace lcbinint;namespace tr=algebraic_boundary::triple;
int main(){int id,j;double s,q,sep,ang,q2,X,Y,rho;tr::PreparedRegularSupport prep;magnification::PointSourceMagnifier solver;std::cout<<std::setprecision(17);while(std::cin>>id>>j>>s>>q>>sep>>ang>>q2>>X>>Y>>rho){auto g=model::make_triple_lens_geometry_vbm(s,q,sep,ang,q2);std::array<tr::Complex,3> lenses;for(int k=0;k<3;++k)lenses[k]={g.lens_positions[k].x,g.lens_positions[k].y};auto f=tr::primary_frame(lenses,{X,Y},rho,g.masses[1],g.masses[2]);auto m=solver.triple_mag0(g,{X,Y});auto safety=solver.triple_safety_diagnostic(g,{X,Y});double err=6*safety.quadrupole_indicator*rho*rho;if(err<1e-4*m.magnification)prep.caustic_clearance(f.geometry,20*rho);auto clear=prep.caustic_clearance(f.geometry,5*rho);std::cout<<j<<" clear="<<clear.first<<" count="<<clear.second;
if(clear.second>=4){auto h=magnification::triple_approximation::hex<true>(solver,g,{X,Y},rho,0.,clear.second);std::cout<<" hexvalid="<<h.valid<<" hexerr="<<h.error;}
if(clear.second<4){auto plan=prep.plan(f.geometry,1e-4,65536,false);auto next=prep.caustic_clearance(f.geometry,5*rho);std::cout<<" after_plan_clear="<<next.first<<" count="<<next.second;}
std::cout<<"\n";}}
