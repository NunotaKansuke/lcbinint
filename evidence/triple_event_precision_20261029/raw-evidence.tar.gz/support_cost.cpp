#include "lcbinint/magnification/algebraic_boundary/triple/integrator.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/regular_support.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/frame.hpp"
#include <iostream>
#include <iomanip>
#include <ctime>
using namespace lcbinint::algebraic_boundary::triple;
double cpu(){timespec t{};clock_gettime(CLOCK_THREAD_CPUTIME_ID,&t);return t.tv_sec+t.tv_nsec*1e-9;}
int main(){int id,j;double s,q,sep,ang,q2,X,Y,rho;std::cout<<std::setprecision(17);while(std::cin>>id>>j>>s>>q>>sep>>ang>>q2>>X>>Y>>rho){if(id!=514||j!=2)continue;double off=q*s/(1+q),den=1+q+q2;std::array<Complex,3> l{Complex(off,0),Complex(-s/(1+q),0),Complex(off,0)-sep*std::polar(1.,ang)};std::array<double,3> m{1/den,q/den,q2/den};for(auto o:std::array<std::array<int,3>,3>{{{0,1,2},{1,0,2},{2,0,1}}}){auto f=primary_frame({l[o[0]],l[o[1]],l[o[2]]},{X,Y},rho,m[o[1]],m[o[2]]);PreparedRegularSupport prep;IntegrationOptions opt;opt.absolute_tolerance=0;opt.relative_tolerance=.001;if(o[0])opt.event_box_budget=8192;double a=cpu();auto plan=prep.plan(f.geometry,.001,opt.event_box_budget,false);double prepared=cpu()-a;a=cpu();auto z=integrate<true>(f.geometry,0.,opt,plan.completed?&plan:nullptr);double integrated=cpu()-a;std::cout<<"{\"case\":"<<id<<",\"epoch\":"<<j<<",\"frame\":"<<o[0]<<",\"plan_completed\":"<<plan.completed<<",\"plan_reason\":\""<<plan.reason<<"\",\"prepare_seconds\":"<<prepared<<",\"integrate_seconds\":"<<integrated<<",\"support_completed\":"<<z.support.completed<<",\"support_boxes\":"<<z.support.boxes<<",\"converged\":"<<z.converged<<",\"gradient_valid\":"<<z.gradient_valid<<",\"reason\":\""<<z.reason<<"\"}\n"<<std::flush;}}}
