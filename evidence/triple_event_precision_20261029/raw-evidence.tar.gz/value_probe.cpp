#include "lcbinint/magnification/algebraic_boundary/triple/integrator.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/regular_support.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/frame.hpp"
#include <iostream>
#include <iomanip>
using namespace lcbinint::algebraic_boundary::triple;
int main(){int id,j;double s,q,sep,ang,q2,X,Y,rho;std::cout<<std::setprecision(17);while(std::cin>>id>>j>>s>>q>>sep>>ang>>q2>>X>>Y>>rho){double off=q*s/(1+q),den=1+q+q2;std::array<Complex,3> l{Complex(off,0),Complex(-s/(1+q),0),Complex(off,0)-sep*std::polar(1.,ang)};std::array<double,3> m{1/den,q/den,q2/den};for(auto o:std::array<std::array<int,3>,3>{{{0,1,2},{1,0,2},{2,0,1}}}){auto f=primary_frame({l[o[0]],l[o[1]],l[o[2]]},{X,Y},rho,m[o[1]],m[o[2]]);PreparedRegularSupport prep;IntegrationOptions opt;opt.absolute_tolerance=0;opt.relative_tolerance=.001;opt.event_box_budget=8192;auto p=prep.plan(f.geometry,.001,8192,false);int n=0;bool ok=p.completed;for(auto& e:p.events)if(!refine_event_center(e,f.geometry,true)){ok=false;break;}else ++n;std::cout<<id<<" "<<j<<" "<<o[0]<<" plan="<<p.completed<<" refined="<<ok<<" n="<<n;
if(ok){auto z=integrate(f.geometry,0.,opt,&p);std::cout<<" converged="<<z.converged<<" mu="<<z.normalized.f0<<" stop="<<z.reason;}std::cout<<"\n"<<std::flush;}}}
