#include "lcbinint/magnification/point_source_magnifier.hpp"
#include "lcbinint/model/triple_lens_geometry.hpp"
#include <iostream>
#include <iomanip>
int main(){int id,j;double s,q,sep,ang,q2,X,Y,rho;std::cout<<std::setprecision(17);while(std::cin>>id>>j>>s>>q>>sep>>ang>>q2>>X>>Y>>rho){auto g=lcbinint::model::make_triple_lens_geometry_vbm(s,q,sep,ang,q2);lcbinint::magnification::PointSourceMagnifier p;auto m=p.triple_mag0(g,{X,Y});auto d=p.triple_safety_diagnostic(g,{X,Y});std::cout<<id<<" "<<j<<" "<<m.magnification<<" "<<6*d.quadrupole_indicator*rho*rho<<"\n";}}
