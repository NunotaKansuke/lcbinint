import sys
from pathlib import Path
D=Path(__file__).resolve().parent
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable' not in str(f)]
sys.path.insert(0,str(D.parent/'triple_component_completion_20261029/accepted-package'))
import lcbinint,pytest
print(lcbinint._native.__file__,flush=True)
raise SystemExit(pytest.main(['-q','tests/regression/test_triple_ld_radial_resolution.py']))
