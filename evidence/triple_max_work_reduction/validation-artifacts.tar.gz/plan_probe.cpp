#include "regular-probe.hpp"
#include "lcbinint/magnification/algebraic_boundary/triple/integrator.hpp"
#include <chrono>
#include <iostream>
#include <map>
namespace tr=lcbinint::algebraic_boundary::triple;
int main(){double xmin,xmax,y,rho,m1,m2,a,bx,by;std::cin>>xmin>>xmax>>y>>rho>>m1>>m2>>a>>bx>>by;
for(int budget:{64,256,1024,4096}){
 tr::PreparedRegularSupport prepared;std::map<std::string,int>reasons;int completed=0,boxes=0;double elapsed=0,integral_ms=0,checksum=0;int bad=0;
 for(int j=0;j<65;++j){tr::Geometry p{xmin+(xmax-xmin)*j/64,y,rho,m1,m2,a,bx,by};auto start=std::chrono::steady_clock::now();auto plan=prepared.plan(p,1e-3,budget,true);elapsed+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();completed+=plan.completed;boxes+=plan.boxes;reasons[plan.reason]++;
 tr::IntegrationOptions options;options.relative_tolerance=1e-3;options.absolute_tolerance=0;start=std::chrono::steady_clock::now();auto v=tr::integrate(p,.5,options,plan.completed?&plan:nullptr);integral_ms+=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();checksum+=v.magnification;bad+=!v.converged;
 }
 std::cout<<budget<<" completed "<<completed<<" boxes "<<boxes<<" plan_ms "<<elapsed<<" integral_ms "<<integral_ms<<" checksum "<<checksum<<" bad "<<bad;
 for(auto [key,value]:reasons)std::cout<<" ["<<key<<":"<<value<<"]";std::cout<<"\n";
}}
