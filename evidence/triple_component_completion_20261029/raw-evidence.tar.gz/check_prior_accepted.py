import sys,json,time,hashlib
from pathlib import Path
P=Path(__file__).resolve().parent
O=P.parent/'triple_local_chart_followup_20261029'
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable' not in str(f)]
sys.path.insert(0,str(P/'accepted-package'))
import lcbinint as lc
rows=[]
for i in [400,403,433,460,467,484,515]:
 c=json.loads((P.parent/'triple_event_precision_20261029/inputs'/f'{i:04d}.json').read_text())
 m=lc.LightCurve(lens='triple',param_type='vbm',ld_c=c['limb'],options=lc.Options(finite_source_tol=0.,finite_source_reltol=c['rtol']))
 a=time.thread_time();r=m.info([0.],c['params'],with_gradient=True);elapsed=time.thread_time()-a
 v=m.info([0.],c['params'])
 ref=json.loads((O/f'{i:04d}-mp-gradient-v2.json').read_text())
 z=dict(case=i,cpu=elapsed,mu=r.magnifications.tolist(),value_mu=v.magnifications.tolist(),method=r.diagnostics['finite_source_method'].tolist(),rows=[])
 for d in ref['rows']:
  k=list(r.gradient_parameters).index(d['parameter']);g=float(r.gradients[0,k]);truth=float(d['richardson']);error=abs(g-truth)/(1+abs(truth))
  z['rows'].append(dict(parameter=d['parameter'],native=g,reference=truth,scaled_error=error))
 rows.append(z);print(i,z['method'],max(x['scaled_error'] for x in z['rows']),flush=True)
(P/'gradient-comparison.json').write_text(json.dumps(dict(native_sha256=hashlib.sha256(Path(lc._native.__file__).read_bytes()).hexdigest(),rows=rows),indent=2))
