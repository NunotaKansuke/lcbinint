import sys,json,hashlib,subprocess,platform,socket,shutil,shlex
from pathlib import Path
D=Path(__file__).resolve().parent;P=D.parent/'triple_local_chart_followup_20261029';R=Path.cwd().resolve();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((D.parent/'triple_finite_radius_closeout_20261029/PROVENANCE.json').read_text());files=set(old['project_source_hashes'])
for dependency in Path('build-triple-native/CMakeFiles').rglob('*.o.d'):
 for token in shlex.split(dependency.read_text().replace('\\\n',' ')):
  p=Path(token);p=p if p.is_absolute()else R/p
  try:rel=p.resolve().relative_to(R)
  except ValueError:continue
  if p.is_file()and not str(rel).startswith(('build-','evidence/')):files.add(str(rel))
source_hashes={p:sha(p)for p in sorted(files)}
for p in files:
 dst=D/'source-snapshot'/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
wrappers={}
for p in (D/'accepted-package').rglob('*.py'):
 rel=p.relative_to(D/'accepted-package');wrappers[str(rel)]=sha(p);dst=D/'wrapper-snapshot'/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
tests=['tests/triple_algebraic/CMakeLists.txt','tests/triple_algebraic/test_local_images.cpp','tests/triple_algebraic/test_pole_partition.cpp','tests/regression/test_triple_pole_partition.py']
for p in tests:
 dst=D/'test-snapshot'/p;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst)
for tag in ['pole-partition-first','pole-partition-final','pole-ld-final','pole-accepted']:
 shutil.copytree(P/(tag+'-rows'),D/'raw'/(tag+'-rows'),dirs_exist_ok=True);shutil.copy2(P/(tag+'-status.json'),D/'raw'/(tag+'-status.json'))
identity=sha(D/'accepted-package/lcbinint/_lcbinint.cpython-310-x86_64-linux-gnu.so');assert identity==sha('build-triple-native/_lcbinint.cpython-310-x86_64-linux-gnu.so')=='9e14a9155a432863441fa986e3f5cdec1ee81d5173ef00db09714404b8142d91'
changed=[p for p,h in source_hashes.items()if h!=old['project_source_hashes'].get(p)]
assert all(p.startswith('src/lcbinint/magnification/')for p in changed),changed
variants={}
for name in ['partition-only-package','geometry-final-package','ld-package','early-package','accepted-package']:
 variants[name]=sha(D/name/'lcbinint/_lcbinint.cpython-310-x86_64-linux-gnu.so')
prov=dict(base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),branch=subprocess.check_output(['git','branch','--show-current'],text=True).strip(),host=socket.gethostname(),platform=platform.platform(),python=sys.version,compiler=old['compiler'],native_sha256=identity,variants=variants,baseline_native_sha256=old['native_sha256'],source_hashes=source_hashes,changed_sources=changed,wrapper_hashes=wrappers,test_hashes={p:sha(p)for p in tests},vbm_native=old['vbm_native'],vbm_sha256=sha(old['vbm_native']),vbm_version='5.5',resource_budget=dict(cpu_max=8,ram_gib=16,native_workers=4,reference_workers=2,threads_per_library=1,native_worker_address_space_gib=2,vbm_worker_cpu_seconds=8),build_flags={p.parent.name:p.read_text()for p in [Path('build-triple-native/CMakeFiles/lcbinint_magnification.dir/flags.make'),Path('build-triple-native/CMakeFiles/lcbinint_python.dir/flags.make')]},claim_limits=['1880 conditions and 8280 epochs, not arbitrary geometry certification.','90 independent tangent checks are at nine fixed curve centers.','LD stream/controller optimization rejected for angular tangent errors.','gradient_valid reports finite usable tangents, not a full finite-source derivative error bound.','No running jobs remain; all tool sessions monitored to completion.'])
assert prov['vbm_sha256']==old['vbm_native_sha256']
(D/'PROVENANCE.json').write_text(json.dumps(prov,indent=2)+'\n')
tracked=[p for p in changed+tests if subprocess.run(['git','ls-files','--error-unmatch',p],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0]
patch=subprocess.check_output(['git','diff','--',*tracked])
for p in changed+tests:
 if p not in tracked:
  z=subprocess.run(['git','diff','--no-index','--','/dev/null',p],capture_output=True);assert z.returncode==1;patch+=z.stdout
(D/'source.patch').write_bytes(patch)
print(json.dumps(dict(native_sha256=identity,project_files=len(source_hashes),wrappers=len(wrappers),changed_sources=changed,variants=variants),indent=2))
