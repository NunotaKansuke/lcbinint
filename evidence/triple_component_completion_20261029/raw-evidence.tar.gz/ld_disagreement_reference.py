import sys,json,resource,os,time
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent/'triple_event_precision_20261029';case=int(sys.argv[1]);index=1 if case==940 else 2;resource.setrlimit(resource.RLIMIT_CPU,(240,245));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0));os.sched_setaffinity(0,{6 if case==940 else 7})
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];sys.path.insert(0,str(D/'geometry-final-package'));import lcbinint as lc
c=json.loads((O/'inputs'/f'{case:04d}.json').read_text());rows=[];start=time.thread_time()
for tol in [1e-9,1e-10]:
 m=lc.LightCurve(lens='triple',param_type='vbm',ld_c=c['limb'],options=lc.Options(finite_source_tol=0.,finite_source_reltol=tol))
 for name in ['alpha','ang']:
  for h in [1e-5,3e-6,1e-6]:
   a=dict(c['params']);b=dict(a);a[name]+=h;b[name]-=h;r=dict(case=case,index=index,parameter=name,h=h,rtol=tol)
   try:
    va=m.magnification([c['epochs'][index]],a).magnifications[0];vb=m.magnification([c['epochs'][index]],b).magnifications[0];r.update(plus=float(va),minus=float(vb),difference=float((va-vb)/(2*h)))
   except Exception as exc:r['error']=repr(exc)
   rows.append(r);(D/f'{case:04d}-ld-disagreement-reference.json').write_text(json.dumps(rows,indent=2));print(r,flush=True)
