import sys,os,json,hashlib,time,subprocess,concurrent.futures
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent/'triple_event_precision_20261029';H=D/'holdout';(H/'inputs').mkdir(parents=True,exist_ok=True);(H/'rows').mkdir(exist_ok=True)
worker=(O/'worker.py').read_text().replace('(60,62)','(8,10)');(D/'vbm_worker.py').write_text(worker)
cases=[]
for case in [439,499]:
 original=json.loads((O/'inputs'/f'{case:04d}.json').read_text())
 for variant in range(4):
  for limb in [0.,.5,1.]:
   c=json.loads(json.dumps(original));p=c['params'];p['s']*=1+[-.03,.03,0.,0.][variant];p['sep2']*=1+[-.03,.03,0.,0.][variant]
   if variant==2:p['q']*=.7;p['q2']*=2
   if variant==3:p['q']*=1.3;p['rho']*=.7
   c.update(name=f'pole-partition-{case}-{variant}-ld{limb}',parent_case=case,variant=variant,limb=limb);cases.append(c)
for case in [439,499]:
 c=json.loads((O/'inputs'/f'{case:04d}.json').read_text());c['parent_case']=case;cases.append(c)
jobs=[]
for i,c in enumerate(cases):
 for tight in [False,True]:
  a=dict(c)
  if tight:a['rtol']=1e-8
  f=H/'inputs'/f'{i:04d}'+Path('') if False else H/'inputs'/f'{i:04d}{"-tight"if tight else""}.json'
  f.write_text(json.dumps(a));jobs +=[(i,e,tight,f)for e in (['SinglePoly','MultiPoly','NoPoly']if tight else ['value','gradient','SinglePoly','MultiPoly','NoPoly'])]
start=time.time();identity=hashlib.sha256((D/'package/lcbinint/_lcbinint.cpython-310-x86_64-linux-gnu.so').read_bytes()).hexdigest()
def task(job):
 i,e,tight,inp=job;f=H/'rows'/f'{i:04d}-{e}{"-tight"if tight else""}.json';h=hashlib.sha256(inp.read_bytes()).hexdigest()
 if f.exists():
  z=json.loads(f.read_text());assert z['input_sha256']==h
  if e in ['value','gradient']:assert z.get('native_sha256')==identity
  return z
 try:
  r=subprocess.run([sys.executable,str(O/'worker.py'if e in ['value','gradient']else D/'vbm_worker.py'),str(inp),e],capture_output=True,text=True,timeout=120 if e in ['value','gradient']else 15,env=dict(os.environ,TRIPLE_BUILD=str(D/'package'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
  z=json.loads(r.stdout)if r.returncode==0 else dict(classification='worker_exit',returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
 except Exception as exc:z=dict(classification='harness_error',error=repr(exc))
 z.update(case=i,engine=e,tight=tight,input_sha256=h);tmp=f.with_suffix('.writing');tmp.write_text(json.dumps(z,indent=2));tmp.replace(f);return z
counts={}
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for n,z in enumerate(pool.map(task,jobs),1):
  counts[z['engine']+':'+str(z['tight'])+':'+z['classification']]=counts.get(z['engine']+':'+str(z['tight'])+':'+z['classification'],0)+1
  status=dict(state='RUNNING',completed=n,total=len(jobs),counts=counts,elapsed=time.time()-start,native_sha256=identity);(H/'status.json').write_text(json.dumps(status,indent=2));print(n,z['case'],z['engine'],z['tight'],z['classification'],flush=True)
status['state']='COMPLETE_WITH_FINDINGS'if any(z.endswith(('worker_exit','harness_error','exception','nonconverged','invalid_value','invalid_gradient'))for z in counts)else'COMPLETE';(H/'status.json').write_text(json.dumps(status,indent=2));print(json.dumps(status),flush=True)
