import sys,json,time
from pathlib import Path
D=Path(__file__).resolve().parent
sys.argv=[str(D/'green_reference.py'),'439']
ns={'__file__':str(D/'green_reference.py'),'__name__':'independent_holdout'}
exec(compile((D/'green_reference.py').read_text().split('outpath=D/')[0],str(D/'green_reference.py'),'exec'),ns)
rows=[];mp=ns['mp'];Q=ns['Q']
for i in range(0,24,3):
 c=json.loads((D/'holdout/inputs'/f'{i:04d}.json').read_text());p={k:Q(v)for k,v in c['params'].items()}
 for n in [64,128]:
  mu=ns['green'](p,0.,n);rows.append(dict(case=i,nodes=n,mu=str(mu)));(D/'holdout/independent-green.json').write_text(json.dumps(rows,indent=2));print(i,n,mp.nstr(mu,20),flush=True)
