import json,sys,hashlib
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent/'triple_event_precision_20261029'
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];sys.path.insert(0,str(D/'accepted-package'))
import lcbinint as lc
rows=[]
for i in [439,499]:
 c=json.loads((O/'inputs'/f'{i:04d}.json').read_text());ref=json.loads((D/f'{i:04d}-green.json').read_text())
 m=lc.LightCurve(lens='triple',param_type='vbm',ld_c=c['limb'],options=lc.Options(finite_source_tol=0.,finite_source_reltol=c['rtol']))
 r=m.info(c['epochs'],c['params'],with_gradient=True);v=m.info(c['epochs'],c['params']);assert all(r.status==0)and all(r.gradient_valid)and all(v.status==0)
 row=dict(case=i,mu=r.magnifications.tolist(),value_mu=v.magnifications.tolist(),methods=r.diagnostics['finite_source_method'].tolist(),gradients=[],value_errors=[])
 for j in range(5):
  refs=[float(a['mu'])for a in ref['values']if a['index']==j and a['nodes']>=64];assert len(refs)==2 and max(refs)/min(refs)-1<1e-10
  row['value_errors'].append(max(abs(r.magnifications[j]/a-1)for a in refs))
 for a in ref['gradients']:
  name=a['parameter'];truth=float(a['richardson']);native=float(r.gradients[2,list(r.gradient_parameters).index(name)]);error=abs(native-truth)/(1+abs(truth));row['gradients'].append(dict(parameter=name,native=native,reference=truth,scaled_error=error))
 rows.append(row)
(D/'independent-comparison.json').write_text(json.dumps(dict(native_sha256=hashlib.sha256(Path(lc._native.__file__).read_bytes()).hexdigest(),rows=rows),indent=2));print([(r['case'],max(r['value_errors']),max(a['scaled_error']for a in r['gradients']))for r in rows])
