import sys,json,time,resource,os
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent/'triple_event_precision_20261029';os.sched_setaffinity(0,{7});resource.setrlimit(resource.RLIMIT_CPU,(180,185));resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
sys.meta_path=[f for f in sys.meta_path if '_lcbinint_editable'not in str(f)];sys.path.insert(0,str(D/'geometry-final-package'))
import lcbinint as lc
out=[]
for i,j,key,steps in [(972,1,'t0',[2e-8,1e-8,5e-9,2e-9,1e-9])]:
 c=json.loads((O/'inputs'/f'{i:04d}.json').read_text());m=lc.LightCurve(lens='triple',param_type='vbm',ld_c=c['limb'],options=lc.Options(finite_source_tol=0.,finite_source_reltol=1e-9));row=dict(case=i,index=j,parameter=key,rtol=1e-9,rows=[])
 for h in steps:
  try:
   a=dict(c['params']);b=dict(a);a[key]+=h;b[key]-=h;va=m.magnification([c['epochs'][j]],a).magnifications[0];vb=m.magnification([c['epochs'][j]],b).magnifications[0];row['rows'].append(dict(h=h,plus=float(va),minus=float(vb),difference=float((va-vb)/(2*h))))
  except Exception as exc:row['error']=repr(exc);break
 out.append(row);(D/'ld-fine-difference.json').write_text(json.dumps(out,indent=2));print(row,flush=True)
