"""Independent 70-digit original-equation Green contour; validation only."""
import sys,json,time,math,resource,os
from pathlib import Path
D=Path(__file__).resolve().parent;P=D.parent/'triple_local_chart_followup_20261029';case=int(sys.argv[1]);sys.argv=[str(P/'mp_reference.py'),str(case)]
ns={'__file__':str(P/'mp_reference.py'),'__name__':'independent_reference'};exec(compile((P/'mp_reference.py').read_text().split('def disk(')[0].replace('resource.setrlimit(resource.RLIMIT_CPU,(300,305));',''),str(P/'mp_reference.py'),'exec'),ns)
resource.setrlimit(resource.RLIMIT_CPU,(1200,1205));mp=ns['mp'];Q=mp.mpf;C=mp.mpc;c=ns['c'];base={k:Q(v)for k,v in c['params'].items()};start=time.thread_time();maxres=Q(0)
def geometry(p):
 den=1+p['q']+p['q2'];off=p['q']*p['s']/(1+p['q']);return [C(off),C(-p['s']/(1+p['q'])),C(off-p['sep2']*mp.cos(p['ang']),-p['sep2']*mp.sin(p['ang']))],[1/den,p['q']/den,p['q2']/den]
def green(p,t,n):
 global maxres
 ns['l'],ns['m']=geometry(p);tau=(Q(t)-p['t0'])/p['tE'];w=C(tau*mp.cos(p['alpha'])-p['u0']*mp.sin(p['alpha']),tau*mp.sin(p['alpha'])+p['u0']*mp.cos(p['alpha']));rho=p['rho'];roots=ns['roots_at'](w+rho);total=Q(0)
 for k in range(n):
  phase=mp.exp(2j*mp.pi*k/n);target=w+rho*phase;wp=1j*rho*phase;images=[ns['solve'](z,target)for z in roots];assert all(z is not None for z in images)
  roots=[z[0] for z in images];assert len({mp.nstr(z,45)for z in roots})==4
  assert sum(a[1]>0 for a in images)==1
  for z,det,res in images:
   maxres=max(maxres,res);shear=ns['field'](z,target)[1];zp=(wp-shear*mp.conj(wp))/det;total+=mp.sign(det)*mp.im(mp.conj(z)*zp)
 return total/(n*rho*rho)
outpath=D/f'{case:04d}-green.json';out=json.loads(outpath.read_text())if outpath.exists()else dict(case=case,dps=70,values=[],gradients=[])
def save():
 out.update(cpu_seconds=time.thread_time()-start,maximum_original_equation_residual=str(maxres));outpath.write_text(json.dumps(out,indent=2))
for j,t in enumerate(c['epochs']):
 for n in [32,64,128]:
  if any(r['index']==j and r['nodes']==n for r in out['values']):continue
  v=green(base,t,n);out['values'].append(dict(index=j,nodes=n,mu=str(v)));save();print(case,'value',j,n,mp.nstr(v,20),flush=True)
steps=dict(t0=Q('1e-5'),u0=base['u0']*Q('.001'),tE=Q('.001'),alpha=Q('.0001'),rho=base['rho']*Q('.001'),s=base['s']*Q('.000001'),q=base['q']*Q('.0001'),q2=base['q2']*Q('.001'),sep2=base['sep2']*Q('.000001'),ang=Q('.000001'))
for name,h in steps.items():
 if any(r['parameter']==name for r in out['gradients']):continue
 fd=[];raw=[]
 for step in [h,h/2]:
  a=dict(base);b=dict(base);a[name]+=step;b[name]-=step;va=green(a,c['epochs'][2],64);vb=green(b,c['epochs'][2],64);fd.append((va-vb)/(2*step));raw.append(dict(h=str(step),plus=str(va),minus=str(vb)))
 rich=(4*fd[1]-fd[0])/3;out['gradients'].append(dict(parameter=name,estimates=list(map(str,fd)),richardson=str(rich),raw=raw));save();print(case,'gradient',name,mp.nstr(rich,20),flush=True)
