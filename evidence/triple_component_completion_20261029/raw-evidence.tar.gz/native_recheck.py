import json,sys,os,subprocess,hashlib,concurrent.futures
from pathlib import Path
D=Path(__file__).resolve().parent;O=D.parent/'triple_event_precision_20261029';H=D/'holdout';R=H/'accepted-rows';R.mkdir(exist_ok=True);identity=hashlib.sha256((D/'accepted-package/lcbinint/_lcbinint.cpython-310-x86_64-linux-gnu.so').read_bytes()).hexdigest()
def run(job):
 i,e=job;inp=H/'inputs'/f'{i:04d}.json';f=R/f'{i:04d}-{e}.json';h=hashlib.sha256(inp.read_bytes()).hexdigest()
 if f.exists():
  z=json.loads(f.read_text());assert z['native_sha256']==identity and z['input_sha256']==h;return z
 r=subprocess.run([sys.executable,str(O/'worker.py'),str(inp),e],capture_output=True,text=True,timeout=120,env=dict(os.environ,TRIPLE_BUILD=str(D/'accepted-package'),OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1'))
 z=json.loads(r.stdout)if r.returncode==0 else dict(classification='worker_exit',returncode=r.returncode,stdout=r.stdout,stderr=r.stderr);z.update(case=i,engine=e,input_sha256=h);f.write_text(json.dumps(z,indent=2));return z
rows=[]
with concurrent.futures.ThreadPoolExecutor(max_workers=2)as pool:
 for z in pool.map(run,[(i,e)for i in range(26)for e in ['value','gradient']]):rows.append(z);print(z['case'],z['engine'],z['classification'],flush=True)
assert len(rows)==52 and all(z['classification']=='ok'for z in rows)
(H/'accepted-status.json').write_text(json.dumps(dict(state='COMPLETE',completed=52,native_sha256=identity),indent=2))
